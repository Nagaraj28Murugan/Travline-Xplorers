
import { Package, Testimonial, ServiceItem, ItineraryDay } from './types';

// Helper to create a default itinerary based on landmarks
const createItinerary = (location: string, days: number, landmarks: string[]): ItineraryDay[] => {
  const itinerary: ItineraryDay[] = [];
  itinerary.push({ day: 1, title: 'Arrival & Welcome', description: `Arrive at ${location}, check-in to your hotel/resort, and enjoy a welcome drink. Relax and acclimatize to the weather.` });
  
  const itemsPerDay = Math.max(1, Math.ceil(landmarks.length / (days - 2)));
  let landmarkIndex = 0;

  for (let i = 2; i < days; i++) {
    const dayLandmarks = landmarks.slice(landmarkIndex, landmarkIndex + itemsPerDay);
    landmarkIndex += itemsPerDay;
    
    const title = dayLandmarks.length > 0 ? `Explore ${dayLandmarks[0]}` : `Discovering ${location}`;
    const desc = dayLandmarks.length > 0 
        ? `Enjoy a full day guided tour visiting ${dayLandmarks.join(', ')}. Capture beautiful photos and enjoy local cuisine.` 
        : `Spend the day exploring the local culture, markets, and hidden gems of ${location}.`;
    
    itinerary.push({ day: i, title, description: desc });
  }

  itinerary.push({ day: days, title: 'Departure', description: `Enjoy a final breakfast at your hotel before proceeding to the airport for your flight back home, carrying wonderful memories of ${location}.` });
  
  return itinerary;
};

export const PACKAGES: Package[] = [
  // --- International Packages ---
  
  // Europe
  {
    id: 'pkg-london',
    title: 'London Royal Experience',
    category: 'International',
    location: 'London, UK',
    duration: '5 Days / 4 Nights',
    price: 1800,
    image: 'https://images.unsplash.com/photo-1529655683826-aba9b3e77383?auto=format&fit=crop&w=1000&q=80', // Big Ben
    rating: 4.7,
    description: 'Immerse yourself in British history with visits to Buckingham Palace, the Tower of London, and the iconic Big Ben.',
    gallery: ['https://images.unsplash.com/photo-1513635269975-59663e0ac1ad', 'https://images.unsplash.com/photo-1505761671935-60b3a7427bad'],
    inclusions: ['City Center Hotel', 'Breakfast', 'London Eye Tickets', 'River Cruise'],
    exclusions: ['Flights', 'Lunch & Dinner'],
    itinerary: createItinerary('London', 5, ['Buckingham Palace', 'Tower of London', 'London Eye', 'Big Ben'])
  },
  {
    id: 'pkg-paris-city',
    title: 'Parisian Romance',
    category: 'International',
    location: 'Paris, France',
    duration: '5 Days / 4 Nights',
    price: 1900,
    image: 'https://images.unsplash.com/photo-1502602898657-3e91760cbb34?auto=format&fit=crop&w=1000&q=80', // Paris City / Eiffel Tower
    rating: 4.8,
    description: 'Discover the City of Lights. Visit the Eiffel Tower, the artistic Louvre, and enjoy a magical Seine River cruise.',
    gallery: ['https://images.unsplash.com/photo-1499856871940-b3824ff43265', 'https://images.unsplash.com/photo-1511739001486-91da7fcae330'],
    inclusions: ['Boutique Hotel', 'Breakfast', 'Museum Pass', 'Seine Cruise'],
    exclusions: ['Flights', 'City Tax'],
    itinerary: createItinerary('Paris', 5, ['Eiffel Tower', 'Louvre Museum', 'Notre Dame', 'Seine River cruise'])
  },
  {
    id: 'pkg-rome',
    title: 'Ancient Rome',
    category: 'International',
    location: 'Rome, Italy',
    duration: '5 Days / 4 Nights',
    price: 1600,
    image: 'https://images.unsplash.com/photo-1552832230-c0197dd311b5?auto=format&fit=crop&w=1000&q=80', // Colosseum
    rating: 4.7,
    description: 'Walk through history at the Colosseum, Vatican City, and make a wish at the Trevi Fountain.',
    gallery: ['https://images.unsplash.com/photo-1531572753322-ad063cecc14f', 'https://images.unsplash.com/photo-1555992336-fb0d29498b13'],
    inclusions: ['Hotel Stay', 'Breakfast', 'Colosseum Entry', 'Vatican Tour'],
    exclusions: ['Flights', 'Tourist Tax'],
    itinerary: createItinerary('Rome', 5, ['Colosseum', 'Vatican City', 'Trevi Fountain', 'Pantheon'])
  },
  {
    id: 'pkg-switzerland',
    title: 'Swiss Alpine Wonder',
    category: 'International',
    location: 'Switzerland',
    duration: '6 Days / 5 Nights',
    price: 2500,
    image: 'https://images.unsplash.com/photo-1530122037265-a5f1f91d3b99?auto=format&fit=crop&w=1000&q=80', // Matterhorn/Alps
    rating: 4.9,
    description: 'Breathtaking landscapes awaiting in Interlaken and Zermatt, with a trip to the top of Europe at Jungfraujoch.',
    gallery: ['https://images.unsplash.com/photo-1527668752968-14dc70a27c95', 'https://images.unsplash.com/photo-1492119884860-63772f69b804'],
    inclusions: ['Swiss Travel Pass', 'Mountain Resort', 'Breakfast'],
    exclusions: ['Flights', 'Lunch & Dinner'],
    itinerary: createItinerary('Switzerland', 6, ['Interlaken', 'Zermatt (Matterhorn)', 'Jungfraujoch', 'Lucerne'])
  },
  {
    id: 'pkg-amsterdam',
    title: 'Amsterdam Canals',
    category: 'International',
    location: 'Amsterdam, Netherlands',
    duration: '4 Days / 3 Nights',
    price: 1400,
    image: 'https://images.unsplash.com/photo-1512470876302-687da745ca99?auto=format&fit=crop&w=1000&q=80', // Amsterdam Canals/City
    rating: 4.6,
    description: 'Explore the charming canals, visit the Van Gogh Museum, and see the historic Anne Frank House.',
    gallery: ['https://images.unsplash.com/photo-1585672840545-d81b498522e8'],
    inclusions: ['Canal Hotel', 'Breakfast', 'Canal Cruise Ticket'],
    exclusions: ['Flights', 'Museum Entry Fees'],
    itinerary: createItinerary('Amsterdam', 4, ['Canals', 'Van Gogh Museum', 'Anne Frank House', 'Tulip Gardens'])
  },

  // Middle East
  {
      id: 'pkg-dubai',
      title: 'Dubai Luxury Escape',
      category: 'Family',
      location: 'Dubai, UAE',
      duration: '5 Days / 4 Nights',
      price: 1200,
      image: 'https://images.unsplash.com/photo-1512453979798-5ea90b2009f4?auto=format&fit=crop&w=1000&q=80', // Dubai City/Burj
      rating: 4.8,
      description: 'Skyscrapers, desert safaris, and shopping festivals await you in Dubai.',
      gallery: ['https://images.unsplash.com/photo-1526495124232-a04e1849168c'],
      inclusions: ['5 Star Hotel', 'Desert Safari', 'Burj Khalifa Tickets'],
      exclusions: ['Lunch', 'Tips'],
      itinerary: createItinerary('Dubai', 5, ['Burj Khalifa', 'Dubai Mall', 'Desert Safari', 'Palm Jumeirah'])
  },
  {
    id: 'pkg-abudhabi',
    title: 'Abu Dhabi Highlights',
    category: 'International',
    location: 'Abu Dhabi, UAE',
    duration: '4 Days / 3 Nights',
    price: 1100,
    image: 'https://images.unsplash.com/photo-1546412414-8035e1776c9a?auto=format&fit=crop&w=1000&q=80', // Sheikh Zayed Mosque
    rating: 4.6,
    description: 'Visit the magnificent Sheikh Zayed Mosque and enjoy thrills at Ferrari World on Yas Island.',
    gallery: ['https://images.unsplash.com/photo-1518684079-3c830dcef090'],
    inclusions: ['Yas Island Hotel', 'Breakfast', 'Park Tickets'],
    exclusions: ['Flights', 'Personal Shopping'],
    itinerary: createItinerary('Abu Dhabi', 4, ['Sheikh Zayed Mosque', 'Ferrari World', 'Yas Island'])
  },
  {
    id: 'pkg-istanbul',
    title: 'Historic Istanbul',
    category: 'International',
    location: 'Istanbul, Turkey',
    duration: '5 Days / 4 Nights',
    price: 1300,
    image: 'https://images.unsplash.com/photo-1524231757912-21f4fe3a7200?auto=format&fit=crop&w=1000&q=80', // Istanbul Mosque
    rating: 4.7,
    description: 'Where East meets West. Explore the Hagia Sophia, Blue Mosque, and take a Bosphorus Cruise.',
    gallery: ['https://images.unsplash.com/photo-1545459720-aacfb5092126'],
    inclusions: ['Historic Hotel', 'Breakfast', 'Cruise Ticket'],
    exclusions: ['Flights', 'Visa Fees'],
    itinerary: createItinerary('Istanbul', 5, ['Hagia Sophia', 'Blue Mosque', 'Bosphorus Cruise'])
  },

  // Asia
  {
    id: 'pkg-bangkok',
    title: 'Bangkok Explorer',
    category: 'International',
    location: 'Bangkok, Thailand',
    duration: '5 Days / 4 Nights',
    price: 800,
    image: 'https://images.unsplash.com/photo-1508009603885-50cf7c579365?auto=format&fit=crop&w=1000&q=80', // Wat Arun
    rating: 4.5,
    description: 'Experience the vibrant street life, Grand Palace, Wat Arun, and Floating Markets.',
    gallery: ['https://images.unsplash.com/photo-1563492065599-3520f775eeed'],
    inclusions: ['City Hotel', 'Breakfast', 'Temple Tour'],
    exclusions: ['Flights', 'Lunch & Dinner'],
    itinerary: createItinerary('Bangkok', 5, ['Grand Palace', 'Floating Markets', 'Wat Arun', 'Street Food Tour'])
  },
  {
    id: 'pkg-singapore',
    title: 'Singapore Family Fun',
    category: 'Family',
    location: 'Singapore',
    duration: '5 Days / 4 Nights',
    price: 1500,
    image: 'https://images.unsplash.com/photo-1525625293386-3f8f99389edd?auto=format&fit=crop&w=1000&q=80', // Marina Bay Sands
    rating: 4.8,
    description: 'A futuristic city with Marina Bay Sands, Gardens by the Bay, and fun at Sentosa Island.',
    gallery: ['https://images.unsplash.com/photo-1565967511849-76a60a516170'],
    inclusions: ['Hotel', 'Breakfast', 'Universal Studios Ticket'],
    exclusions: ['Flights', 'Personal Expenses'],
    itinerary: createItinerary('Singapore', 5, ['Marina Bay Sands', 'Sentosa Island', 'Gardens by the Bay', 'Universal Studios'])
  },
  {
      id: 'pkg-bali',
      title: 'Bali Island Life',
      category: 'International',
      location: 'Bali, Indonesia',
      duration: '7 Days / 6 Nights',
      price: 1200,
      image: 'https://images.unsplash.com/photo-1537996194471-e657df975ab4?auto=format&fit=crop&w=1000&q=80', // Bali Temple
      rating: 4.9,
      description: 'Rice terraces in Ubud, sunset at Tanah Lot, and beach vibes in Seminyak.',
      gallery: ['https://images.unsplash.com/photo-1518548419970-58e3b4079ab2', 'https://images.unsplash.com/photo-1552733407-5d5c46c3bb3b'],
      inclusions: ['Flights', 'Private Pool Villa', 'Candlelight Dinner'],
      exclusions: ['Personal Shopping', 'Optional Watersports'],
      itinerary: createItinerary('Bali', 7, ['Ubud Rice Terraces', 'Tanah Lot Temple', 'Seminyak Beach', 'Kuta'])
  },
  {
    id: 'pkg-maldives',
    title: 'Maldives Paradise',
    category: 'Honeymoon',
    location: 'Maldives',
    duration: '5 Days / 4 Nights',
    price: 2200,
    image: 'https://images.unsplash.com/photo-1514282401047-d79a71a590e8?auto=format&fit=crop&w=1000&q=80', // Water Villas
    rating: 4.9,
    description: 'Ultimate luxury with overwater villas, crystal clear waters for snorkeling, and scuba diving.',
    gallery: ['https://images.unsplash.com/photo-1573843981267-be1999ff37cd'],
    inclusions: ['Overwater Villa', 'All Meals', 'Speedboat Transfer'],
    exclusions: ['Flights', 'Scuba Gear Rental'],
    itinerary: createItinerary('Maldives', 5, ['Male Atoll', 'Snorkeling Reefs', 'Scuba Diving', 'Resort Relaxation'])
  },

  // Americas
  {
    id: 'pkg-nyc',
    title: 'New York City Lights',
    category: 'International',
    location: 'New York, USA',
    duration: '5 Days / 4 Nights',
    price: 2400,
    image: 'https://images.unsplash.com/photo-1496442226666-8d4d0e62e6e9?auto=format&fit=crop&w=1000&q=80', // New York City Lights
    rating: 4.7,
    description: 'The city that never sleeps. Visit the Statue of Liberty, Times Square, and see a Broadway show.',
    gallery: ['https://images.unsplash.com/photo-1485871981535-5be84380f471'],
    inclusions: ['Manhattan Hotel', 'Breakfast', 'Statue Ferry'],
    exclusions: ['Flights', 'Broadway Tickets', 'Visa'],
    itinerary: createItinerary('New York', 5, ['Statue of Liberty', 'Times Square', 'Central Park', 'Broadway'])
  },

  // Oceania
  {
    id: 'pkg-sydney',
    title: 'Sydney Harbor',
    category: 'International',
    location: 'Sydney, Australia',
    duration: '6 Days / 5 Nights',
    price: 2100,
    image: 'https://images.unsplash.com/photo-1506973035872-a4ec16b8e8d9?auto=format&fit=crop&w=1000&q=80', // Opera House
    rating: 4.7,
    description: 'Iconic views of the Opera House, Harbour Bridge, and sun-soaked Bondi Beach.',
    gallery: ['https://images.unsplash.com/photo-1523428098304-48548197502b'],
    inclusions: ['Harbor View Hotel', 'Breakfast', 'Opera House Tour'],
    exclusions: ['Flights', 'Visa', 'Lunch'],
    itinerary: createItinerary('Sydney', 6, ['Sydney Opera House', 'Harbour Bridge', 'Bondi Beach'])
  },
  {
    id: 'pkg-queenstown',
    title: 'New Zealand Adventure',
    category: 'Adventure',
    location: 'Queenstown, New Zealand',
    duration: '6 Days / 5 Nights',
    price: 2300,
    image: 'https://images.unsplash.com/photo-1589802829985-817e51171b92?auto=format&fit=crop&w=1000&q=80', // Adventure / Mountains
    rating: 4.9,
    description: 'The adventure capital of the world. Milford Sound cruises and adrenaline sports awaits.',
    gallery: ['https://images.unsplash.com/photo-1507699622177-3888e95e8155'],
    inclusions: ['Lodge Stay', 'Breakfast', 'Milford Sound Cruise'],
    exclusions: ['Flights', 'Bungee Jumping Fees'],
    itinerary: createItinerary('Queenstown', 6, ['Adventure Sports', 'Milford Sound', 'Lake Wakatipu'])
  },

  // --- Domestic Packages (India) ---
  
  // New & Updated Packages
  {
    id: 'pkg-ooty',
    title: 'Ooty - Queen of Hills',
    category: 'Family',
    location: 'Ooty, Tamil Nadu',
    duration: '3 Days / 2 Nights',
    price: 250,
    image: 'https://images.unsplash.com/photo-1534777367038-9404f45b869a?auto=format&fit=crop&w=1000&q=80', // Ooty Tea Gardens/Hills
    gallery: ['https://images.unsplash.com/photo-1589204097412-f793540192e2', 'https://images.unsplash.com/photo-1594895648839-a99f18b57703'],
    rating: 4.7,
    description: 'Relax in the cool climate of Ooty, visiting the Botanical Gardens, Ooty Lake, and Dodabetta Peak.',
    inclusions: ['Resort Stay', 'Breakfast', 'Sightseeing Cabs'],
    exclusions: ['Lunch & Dinner', 'Entry Fees'],
    itinerary: createItinerary('Ooty', 3, ['Botanical Garden', 'Ooty Lake', 'Dodabetta Peak'])
  },
  {
    id: 'pkg-munnar',
    title: 'Munnar Tea Garden Paradise',
    category: 'Domestic',
    location: 'Munnar, Kerala',
    duration: '3 Days / 2 Nights',
    price: 280,
    image: 'https://images.unsplash.com/photo-1593693397690-362cb96667e3?auto=format&fit=crop&w=1000&q=80', // Munnar Hills
    gallery: ['https://images.unsplash.com/photo-1593693397690-362cb96667e3'],
    rating: 4.8,
    description: 'Explore the rolling tea gardens, Eravikulam National Park, and breathtaking views at Top Station.',
    inclusions: ['Hill View Hotel', 'Breakfast', 'Tea Museum Entry'],
    exclusions: ['Lunch', 'Personal Expenses'],
    itinerary: createItinerary('Munnar', 3, ['Tea Museum', 'Eravikulam National Park', 'Top Station'])
  },
  {
    id: 'pkg-kodai',
    title: 'Kodaikanal Retreat',
    category: 'Domestic',
    location: 'Kodaikanal, Tamil Nadu',
    duration: '3 Days / 2 Nights',
    price: 260,
    image: 'https://images.unsplash.com/photo-1549141077-83c79c855307?auto=format&fit=crop&w=1000&q=80', // Kodaikanal
    gallery: ['https://images.unsplash.com/photo-1589204097412-f793540192e2'],
    rating: 4.6,
    description: 'Walk through Coaker\'s Walk, see the majestic Pillar Rocks, and boat in Kodai Lake.',
    inclusions: ['Hotel Stay', 'Breakfast', 'Boating'],
    exclusions: ['Lunch', 'Shopping'],
    itinerary: createItinerary('Kodaikanal', 3, ['Coaker\'s Walk', 'Pillar Rocks', 'Kodai Lake'])
  },
  {
    id: 'pkg-wayanad',
    title: 'Wayanad Adventure',
    category: 'Adventure',
    location: 'Wayanad, Kerala',
    duration: '3 Days / 2 Nights',
    price: 270,
    image: 'https://images.unsplash.com/photo-1606830509618-936676356c36?auto=format&fit=crop&w=1000&q=80', // Wayanad
    gallery: ['https://images.unsplash.com/photo-1618585935764-770335805e6b'],
    rating: 4.7,
    description: 'Explore ancient Edakkal Caves, the massive Banasura Sagar Dam, and lush wildlife.',
    inclusions: ['Resort Stay', 'Breakfast & Dinner', 'Jeep Safari'],
    exclusions: ['Lunch', 'Entry Fees'],
    itinerary: createItinerary('Wayanad', 3, ['Edakkal Caves', 'Banasura Sagar Dam', 'Wildlife Sanctuary'])
  },
  {
    id: 'pkg-hampi',
    title: 'Hampi - UNESCO Heritage Site',
    category: 'Domestic',
    location: 'Hampi, Karnataka',
    duration: '3 Days / 2 Nights',
    price: 220,
    image: 'https://images.unsplash.com/photo-1620766182966-c6eb5ed2b788?auto=format&fit=crop&w=1000&q=80', // Hampi Chariot
    gallery: ['https://images.unsplash.com/photo-1620766182966-c6eb5ed2b788'],
    rating: 4.8,
    description: 'A UNESCO World Heritage site. Visit Virupaksha Temple and the architectural marvels of the Vijayanagara Empire.',
    inclusions: ['Guesthouse Stay', 'Breakfast', 'Guide'],
    exclusions: ['Lunch', 'Coracle Ride'],
    itinerary: createItinerary('Hampi', 3, ['Virupaksha Temple', 'Vijayanagara Ruins', 'Vittala Temple'])
  },
  {
    id: 'pkg-mysore',
    title: 'Mysore - Royal Heritage City',
    category: 'Domestic',
    location: 'Mysore, Karnataka',
    duration: '2 Days / 1 Night',
    price: 200,
    image: 'https://images.unsplash.com/photo-1590050752117-238cb0fb12b1?auto=format&fit=crop&w=1000&q=80', // Mysore Palace
    gallery: ['https://images.unsplash.com/photo-1600618528240-fb9fc964b853'],
    rating: 4.5,
    description: 'Marvel at the Mysore Palace and hike Chamundi Hills.',
    inclusions: ['Hotel Stay', 'Breakfast', 'Sightseeing'],
    exclusions: ['Camera Fees', 'Dinner'],
    itinerary: createItinerary('Mysore', 2, ['Mysore Palace', 'Chamundi Hills', 'Brindavan Gardens'])
  },
  {
    id: 'pkg-rameswaram',
    title: 'Spiritual Rameswaram',
    category: 'Domestic',
    location: 'Rameswaram, Tamil Nadu',
    duration: '2 Days / 1 Night',
    price: 180,
    image: 'https://images.unsplash.com/photo-1629217316921-36526154564c?auto=format&fit=crop&w=1000&q=80', // Rameswaram Corridor
    gallery: ['https://images.unsplash.com/photo-1605634952069-7096e1744883'],
    rating: 4.6,
    description: 'A spiritual journey to Rameswaram Temple and a drive on the Pamban Bridge.',
    inclusions: ['Hotel Stay', 'Breakfast', 'Temple Assistance'],
    exclusions: ['Lunch', 'Pooja Fees'],
    itinerary: createItinerary('Rameswaram', 2, ['Rameswaram Temple', 'Pamban Bridge', 'Dhanushkodi'])
  },
  {
    id: 'pkg-kanyakumari',
    title: 'Kanyakumari Sunrise',
    category: 'Domestic',
    location: 'Kanyakumari, Tamil Nadu',
    duration: '2 Days / 1 Night',
    price: 180,
    image: 'https://images.unsplash.com/photo-1622030256860-64259a44c4b6?auto=format&fit=crop&w=1000&q=80', // Vivekananda Rock
    gallery: ['https://images.unsplash.com/photo-1590422915839-4467339d67b2'],
    rating: 4.5,
    description: 'Witness the sunrise at Vivekananda Rock Memorial and visit Triveni Sangam.',
    inclusions: ['Sea View Hotel', 'Breakfast', 'Ferry Tickets'],
    exclusions: ['Lunch', 'Dinner'],
    itinerary: createItinerary('Kanyakumari', 2, ['Vivekananda Rock', 'Triveni Sangam', 'Sunset Point'])
  },
  {
    id: 'pkg-alleppey',
    title: 'Alleppey - Backwater Heaven',
    category: 'Honeymoon',
    location: 'Alleppey, Kerala',
    duration: '2 Days / 1 Night',
    price: 250,
    image: 'https://images.unsplash.com/photo-1602216056096-3b40cc0c9944?auto=format&fit=crop&w=1000&q=80', // Houseboat Close up
    gallery: ['https://images.unsplash.com/photo-1593693397690-362cb96667e3'],
    rating: 4.9,
    description: 'Float through the backwaters of Alleppey in a traditional houseboat on Vembanad Lake.',
    inclusions: ['Private Houseboat', 'All Meals', 'Welcome Drink'],
    exclusions: ['Transport to Alleppey', 'Personal Expenses'],
    itinerary: createItinerary('Alleppey', 2, ['Houseboat Cruise', 'Vembanad Lake', 'Local Village Walk'])
  },
  {
    id: 'pkg-tirupati',
    title: 'Tirupati Pilgrimage',
    category: 'Domestic',
    location: 'Tirupati, Andhra Pradesh',
    duration: '2 Days / 1 Night',
    price: 150,
    image: 'https://images.unsplash.com/photo-1632734914109-775677e5c54b?auto=format&fit=crop&w=1000&q=80', // Tirupati Temple
    gallery: ['https://images.unsplash.com/photo-1622030256860-64259a44c4b6'],
    rating: 4.8,
    description: 'Seek blessings at the holy Tirumala Temple.',
    inclusions: ['Hotel Stay', 'Breakfast', 'Darshan Assistance'],
    exclusions: ['Lunch', 'Special Darshan Ticket Cost'],
    itinerary: createItinerary('Tirupati', 2, ['Tirumala Temple', 'Kapila Theertham', 'Silathoranam'])
  },
  {
    id: 'pkg-pondy',
    title: 'Pondicherry - French Riviera of the East',
    category: 'Domestic',
    location: 'Pondicherry',
    duration: '3 Days / 2 Nights',
    price: 350,
    image: 'https://images.unsplash.com/photo-1582554402636-69a6327b3b4d?auto=format&fit=crop&w=1000&q=80', // Pondicherry Streets
    gallery: ['https://images.unsplash.com/photo-1582554402636-69a6327b3b4d'],
    rating: 4.6,
    description: 'Experience French architecture, relax at Promenade Beach, and visit Auroville.',
    inclusions: ['Boutique Hotel', 'Breakfast', 'Bicycle Rental'],
    exclusions: ['Lunch & Dinner', 'Travel to Pondy'],
    itinerary: createItinerary('Pondicherry', 3, ['French Quarter', 'Promenade Beach', 'Auroville'])
  },
  {
    id: 'pkg-mahabalipuram',
    title: 'Mahabalipuram Heritage',
    category: 'Domestic',
    location: 'Mahabalipuram, Tamil Nadu',
    duration: '2 Days / 1 Night',
    price: 160,
    image: 'https://images.unsplash.com/photo-1590422915839-4467339d67b2?auto=format&fit=crop&w=1000&q=80', // Shore Temple
    gallery: ['https://images.unsplash.com/photo-1629217316921-36526154564c'],
    rating: 4.5,
    description: 'Admire the Shore Temple and Pancha Rathas, masterpieces of Pallava architecture.',
    inclusions: ['Beach Resort', 'Breakfast', 'Entry Fees'],
    exclusions: ['Lunch', 'Transport'],
    itinerary: createItinerary('Mahabalipuram', 2, ['Shore Temple', 'Pancha Rathas', 'Arjuna\'s Penance'])
  },

  // Other Existing Domestic Packages
  {
    id: 'pkg-delhi',
    title: 'Historic Delhi Tour',
    category: 'Domestic',
    location: 'New Delhi',
    duration: '3 Days / 2 Nights',
    price: 300,
    image: 'https://images.unsplash.com/photo-1587474265584-bc779c334555?auto=format&fit=crop&w=1000&q=80', // India Gate/Humayun
    gallery: ['https://images.unsplash.com/photo-1595658658481-d53d3f9998e2', 'https://images.unsplash.com/photo-1585135497273-1a86b09fe70e'],
    rating: 4.6,
    description: 'Explore the heart of India with visits to the India Gate, Red Fort, Qutub Minar, and Lotus Temple.',
    inclusions: ['Hotel Stay', 'Breakfast', 'Local Transfers', 'Guide'],
    exclusions: ['Flights', 'Entry Fees'],
    itinerary: createItinerary('Delhi', 3, ['India Gate', 'Red Fort', 'Qutub Minar', 'Lotus Temple'])
  },
  {
    id: 'pkg-agra',
    title: 'Agra - City of Love',
    category: 'Domestic',
    location: 'Agra, Uttar Pradesh',
    duration: '2 Days / 1 Night',
    price: 200,
    image: 'https://images.unsplash.com/photo-1564507592333-c60657eea523?auto=format&fit=crop&w=1000&q=80', // Taj Mahal
    gallery: ['https://images.unsplash.com/photo-1548013146-72479768bada'],
    rating: 4.8,
    description: 'Witness the majesty of the Taj Mahal, Agra Fort, and the historic Fatehpur Sikri.',
    inclusions: ['Hotel Stay', 'Breakfast', 'Sightseeing'],
    exclusions: ['Lunch', 'Personal Expenses'],
    itinerary: createItinerary('Agra', 2, ['Taj Mahal', 'Agra Fort', 'Fatehpur Sikri'])
  },
  {
    id: 'pkg-jaipur',
    title: 'Jaipur Royal Getaway',
    category: 'Domestic',
    location: 'Jaipur, Rajasthan',
    duration: '3 Days / 2 Nights',
    price: 350,
    image: 'https://images.unsplash.com/photo-1477587458883-47145ed94245?auto=format&fit=crop&w=1000&q=80', // Hawa Mahal
    gallery: ['https://images.unsplash.com/photo-1477587458883-47145ed94245'],
    rating: 4.7,
    description: 'Immerse yourself in the Pink City with Hawa Mahal, City Palace, and Amber Fort.',
    inclusions: ['Heritage Hotel Stay', 'Breakfast', 'Guide', 'Transport'],
    exclusions: ['Camel Ride', 'Dinner'],
    itinerary: createItinerary('Jaipur', 3, ['Hawa Mahal', 'City Palace', 'Amber Fort'])
  },
  {
    id: 'pkg-varanasi',
    title: 'Spiritual Varanasi',
    category: 'Domestic',
    location: 'Varanasi, Uttar Pradesh',
    duration: '3 Days / 2 Nights',
    price: 300,
    image: 'https://images.unsplash.com/photo-1561361513-2d000a50f0dc?auto=format&fit=crop&w=1000&q=80', // Ganga Ghats
    gallery: ['https://images.unsplash.com/photo-1598322648886-d2492d2424b9'],
    rating: 4.5,
    description: 'Experience the spiritual energy of the Ghats of Ganga and Kashi Vishwanath Temple.',
    inclusions: ['Hotel Stay', 'Boat Ride', 'Breakfast'],
    exclusions: ['Donations', 'Flight Tickets'],
    itinerary: createItinerary('Varanasi', 3, ['Ganga Ghats', 'Kashi Vishwanath Temple', 'Sarnath'])
  },
  {
    id: 'pkg-shimla',
    title: 'Shimla Hill Retreat',
    category: 'Domestic',
    location: 'Shimla, Himachal Pradesh',
    duration: '4 Days / 3 Nights',
    price: 400,
    image: 'https://images.unsplash.com/photo-1562649700-6f28464d1276?auto=format&fit=crop&w=1000&q=80', // Shimla Hills/Snow
    gallery: ['https://images.unsplash.com/photo-1585061688647-7973c9f76a06'],
    rating: 4.6,
    description: 'Enjoy the colonial charm of Mall Road, Jakhoo Temple, and the snow-capped views at Kufri.',
    inclusions: ['Mountain View Hotel', 'Breakfast & Dinner', 'Transfers'],
    exclusions: ['Adventure Sports', 'Lunch'],
    itinerary: createItinerary('Shimla', 4, ['Mall Road', 'Jakhoo Temple', 'Kufri'])
  },
  {
    id: 'pkg-manali',
    title: 'Magical Manali',
    category: 'Domestic',
    location: 'Manali, Himachal Pradesh',
    duration: '4 Days / 3 Nights',
    price: 450,
    image: 'https://images.unsplash.com/photo-1626621341517-bbf3d9990a23?auto=format&fit=crop&w=1000&q=80', // Manali Mountains
    gallery: ['https://images.unsplash.com/photo-1593181625526-1f915c270913'],
    rating: 4.8,
    description: 'Adventure awaits in Solang Valley, Rohtang Pass, and the peaceful Hadimba Temple.',
    inclusions: ['Resort Stay', 'Breakfast & Dinner', 'Sightseeing'],
    exclusions: ['Snow Gear Rental', 'Rohtang Permit Fees'],
    itinerary: createItinerary('Manali', 4, ['Solang Valley', 'Rohtang Pass', 'Hadimba Temple'])
  },
  {
    id: 'pkg-amritsar',
    title: 'Divine Amritsar',
    category: 'Domestic',
    location: 'Amritsar, Punjab',
    duration: '3 Days / 2 Nights',
    price: 250,
    image: 'https://images.unsplash.com/photo-1587574293340-e0011c4e8ecf?auto=format&fit=crop&w=1000&q=80', // Golden Temple
    gallery: ['https://images.unsplash.com/photo-1627914046757-9d7831154563'],
    rating: 4.7,
    description: 'Visit the holy Golden Temple, historic Jallianwala Bagh, and witness the Wagah Border ceremony.',
    inclusions: ['Hotel Stay', 'Breakfast', 'Wagah Border Cabs'],
    exclusions: ['Lunch', 'Personal Shopping'],
    itinerary: createItinerary('Amritsar', 3, ['Golden Temple', 'Jallianwala Bagh', 'Wagah Border'])
  },

  // West India
  {
    id: 'pkg-goa',
    title: 'Goa Beach Party',
    category: 'Domestic',
    location: 'Goa',
    duration: '5 Days / 4 Nights',
    price: 500,
    image: 'https://images.unsplash.com/photo-1512343879784-a960bf40e7f2?auto=format&fit=crop&w=1000&q=80', // Goa Beach
    gallery: ['https://images.unsplash.com/photo-1507525428034-b723cf961d3e'],
    rating: 4.8,
    description: 'Sun, sand, and sea. Explore Baga Beach, Anjuna Beach, and the Basilica of Bom Jesus.',
    inclusions: ['Beach Resort', 'Breakfast', 'Scooter Rental Assistance'],
    exclusions: ['Water Sports', 'Club Entry Fees'],
    itinerary: createItinerary('Goa', 5, ['Baga Beach', 'Anjuna Beach', 'Basilica of Bom Jesus', 'Fort Aguada'])
  },
  {
    id: 'pkg-mumbai',
    title: 'Mumbai City Lights',
    category: 'Domestic',
    location: 'Mumbai, Maharashtra',
    duration: '3 Days / 2 Nights',
    price: 400,
    image: 'https://images.unsplash.com/photo-1567157577867-05ccb1388e66?auto=format&fit=crop&w=1000&q=80', // Mumbai Gateway
    gallery: ['https://images.unsplash.com/photo-1570168007204-dfb528c6958f'],
    rating: 4.5,
    description: 'Experience the Gateway of India, Marine Drive, and the ancient Elephanta Caves.',
    inclusions: ['Hotel Stay', 'Ferry Tickets', 'Breakfast'],
    exclusions: ['Lunch & Dinner', 'Local Train Ticket'],
    itinerary: createItinerary('Mumbai', 3, ['Gateway of India', 'Marine Drive', 'Elephanta Caves'])
  },
  {
    id: 'pkg-udaipur',
    title: 'Romantic Udaipur',
    category: 'Domestic',
    location: 'Udaipur, Rajasthan',
    duration: '3 Days / 2 Nights',
    price: 400,
    image: 'https://images.unsplash.com/photo-1615836245337-f5b9b2303f10?auto=format&fit=crop&w=1000&q=80', // Udaipur Lake Palace
    gallery: ['https://images.unsplash.com/photo-1622308644420-143615f3e400'],
    rating: 4.8,
    description: 'Stay near Lake Pichola and visit the City Palace and Jag Mandir.',
    inclusions: ['Lakeview Hotel', 'Breakfast', 'Boat Ride'],
    exclusions: ['Dinner', 'Shopping'],
    itinerary: createItinerary('Udaipur', 3, ['City Palace', 'Lake Pichola', 'Jag Mandir'])
  },
  {
    id: 'pkg-rann',
    title: 'Rann of Kutch',
    category: 'Domestic',
    location: 'Rann of Kutch, Gujarat',
    duration: '3 Days / 2 Nights',
    price: 350,
    image: 'https://images.unsplash.com/photo-1625902166946-4c9f022723c3?auto=format&fit=crop&w=1000&q=80', // Rann Desert
    gallery: ['https://images.unsplash.com/photo-1548318281-7da3085e6912'],
    rating: 4.6,
    description: 'Witness the surreal White Salt Desert and enjoy the Rann Utsav cultural festival.',
    inclusions: ['Tent City Stay', 'All Meals', 'Cultural Performance'],
    exclusions: ['Personal Expenses', 'Camel Cart'],
    itinerary: createItinerary('Kutch', 3, ['White Salt Desert', 'Rann Utsav', 'Kalo Dungar'])
  },
  {
    id: 'pkg-bengaluru',
    title: 'Garden City Bengaluru',
    category: 'Domestic',
    location: 'Bengaluru, Karnataka',
    duration: '3 Days / 2 Nights',
    price: 350,
    image: 'https://images.unsplash.com/photo-1596176530529-78163a4f7af2?auto=format&fit=crop&w=1000&q=80', // Bangalore Palace/Vidhana Soudha
    gallery: ['https://images.unsplash.com/photo-1582993888031-6e6b455b572d'],
    rating: 4.4,
    description: 'Walk through Lalbagh Botanical Garden, Cubbon Park, and see the Bangalore Palace.',
    inclusions: ['City Hotel', 'Breakfast', 'Transport'],
    exclusions: ['Entry Fees', 'Lunch'],
    itinerary: createItinerary('Bengaluru', 3, ['Lalbagh Botanical Garden', 'Cubbon Park', 'Bangalore Palace'])
  },
  {
    id: 'pkg-coorg',
    title: 'Coorg Coffee Trails',
    category: 'Domestic',
    location: 'Coorg, Karnataka',
    duration: '3 Days / 2 Nights',
    price: 300,
    image: 'https://images.unsplash.com/photo-1588716499383-363692dc54bd?auto=format&fit=crop&w=1000&q=80', // Coorg Hills
    gallery: ['https://images.unsplash.com/photo-1584351332464-96425974464d'],
    rating: 4.7,
    description: 'Relax amidst coffee plantations, visit Abbey Falls, and see Talacauvery.',
    inclusions: ['Homestay', 'Breakfast & Dinner', 'Plantation Walk'],
    exclusions: ['Transport to Coorg', 'Lunch'],
    itinerary: createItinerary('Coorg', 3, ['Coffee Plantations', 'Abbey Falls', 'Talacauvery'])
  },
  {
    id: 'pkg-hyderabad',
    title: 'Heritage Hyderabad',
    category: 'Domestic',
    location: 'Hyderabad, Telangana',
    duration: '3 Days / 2 Nights',
    price: 300,
    image: 'https://images.unsplash.com/photo-1572455044327-724dc5c46c4f?auto=format&fit=crop&w=1000&q=80', // Charminar Heritage
    gallery: ['https://images.unsplash.com/photo-1605553073380-0447387cc397'],
    rating: 4.5,
    description: 'Explore the Charminar, the massive Golconda Fort, and the cinematic Ramoji Film City.',
    inclusions: ['Hotel Stay', 'Breakfast', 'Ramoji Entry Ticket'],
    exclusions: ['Lunch & Dinner', 'Personal Expenses'],
    itinerary: createItinerary('Hyderabad', 3, ['Charminar', 'Golconda Fort', 'Ramoji Film City'])
  },
  {
    id: 'pkg-kerala',
    title: 'Kerala Backwaters',
    category: 'Domestic',
    location: 'Kerala',
    duration: '6 Days / 5 Nights',
    price: 600,
    image: 'https://images.unsplash.com/photo-1602216056096-3b40cc0c9944?auto=format&fit=crop&w=1000&q=80', // Kerala Backwaters/Houseboat
    gallery: ['https://images.unsplash.com/photo-1593693397690-362cb96667e3'],
    rating: 4.9,
    description: 'Cruise the backwaters of Alleppey, visit Munnar Tea Gardens, and relax at Kovalam Beach.',
    inclusions: ['Houseboat Stay', 'Hotel Stay', 'Breakfast', 'AC Transport'],
    exclusions: ['Airfare', 'Lunch'],
    itinerary: createItinerary('Kerala', 6, ['Alleppey Backwaters', 'Munnar Tea Gardens', 'Kovalam Beach', 'Thekkady'])
  },
  {
    id: 'pkg-kolkata',
    title: 'Cultural Kolkata',
    category: 'Domestic',
    location: 'Kolkata, West Bengal',
    duration: '3 Days / 2 Nights',
    price: 300,
    image: 'https://images.unsplash.com/photo-1558431382-27e303142255?auto=format&fit=crop&w=1000&q=80', // Victoria Memorial
    gallery: ['https://images.unsplash.com/photo-1558431382-27e303142255'],
    rating: 4.4,
    description: 'See the Victoria Memorial, the iconic Howrah Bridge, and Dakshineswar Temple.',
    inclusions: ['Hotel Stay', 'Breakfast', 'City Tour'],
    exclusions: ['Lunch', 'Personal Expenses'],
    itinerary: createItinerary('Kolkata', 3, ['Victoria Memorial', 'Howrah Bridge', 'Dakshineswar Temple'])
  },
  {
    id: 'pkg-darjeeling',
    title: 'Darjeeling Hills',
    category: 'Domestic',
    location: 'Darjeeling, West Bengal',
    duration: '4 Days / 3 Nights',
    price: 400,
    image: 'https://images.unsplash.com/photo-1544634076-a901606f41b9?auto=format&fit=crop&w=1000&q=80', // Darjeeling Tea/Kanchenjunga
    gallery: ['https://images.unsplash.com/photo-1626621341517-bbf3d9990a23'],
    rating: 4.7,
    description: 'Watch the sunrise at Tiger Hill, ride the Himalayan Railway, and tour Tea Gardens.',
    inclusions: ['Hill View Hotel', 'Breakfast & Dinner', 'Toy Train Ticket'],
    exclusions: ['Lunch', 'Personal Shopping'],
    itinerary: createItinerary('Darjeeling', 4, ['Tiger Hill', 'Himalayan Railway', 'Tea Gardens'])
  },
  {
    id: 'pkg-bhubaneswar',
    title: 'Odisha Temple Trail',
    category: 'Domestic',
    location: 'Bhubaneswar, Odisha',
    duration: '3 Days / 2 Nights',
    price: 300,
    image: 'https://images.unsplash.com/photo-1626093552097-4c32b5674371?auto=format&fit=crop&w=1000&q=80', // Konark Temple/Odisha
    gallery: ['https://images.unsplash.com/photo-1605634952069-7096e1744883'],
    rating: 4.5,
    description: 'Visit Lingaraj Temple, the majestic Konark Sun Temple, and Puri Jagannath Temple.',
    inclusions: ['Hotel Stay', 'Breakfast', 'AC Cabs'],
    exclusions: ['Temple Donations', 'Lunch'],
    itinerary: createItinerary('Bhubaneswar', 3, ['Lingaraj Temple', 'Konark Sun Temple', 'Puri Jagannath Temple'])
  }
];

export const TESTIMONIALS: Testimonial[] = [
    { id: '1', name: 'Sarah J.', role: 'Traveler', comment: 'Best trip ever! The itinerary was perfect.', image: 'https://randomuser.me/api/portraits/women/44.jpg' },
    { id: '2', name: 'Mike T.', role: 'Adventure Lover', comment: 'Professional guides and amazing support.', image: 'https://randomuser.me/api/portraits/men/32.jpg' },
    { id: '3', name: 'Priya K.', role: 'Honeymooner', comment: 'TRAVLINE made our honeymoon magical.', image: 'https://randomuser.me/api/portraits/women/68.jpg' }
];

export const SERVICES: ServiceItem[] = [
    { id: 's1', title: 'Flight Bookings', description: 'Best deals on international and domestic flights.', icon: 'Plane', partners: ['Emirates', 'Indigo'] },
    { id: 's2', title: 'Hotel Reservations', description: 'Luxury to budget stays worldwide.', icon: 'Building', partners: ['Marriott', 'Hilton'] },
    { id: 's3', title: 'Visa Assistance', description: 'Hassle-free visa processing.', icon: 'FileText', partners: [] }
];
