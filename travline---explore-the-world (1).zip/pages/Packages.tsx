
import React, { useState, useEffect, useMemo } from 'react';
import { Link, useLocation, useNavigate } from 'react-router-dom';
import { PACKAGES } from '../data';
import { MapPin, Clock, Star, SlidersHorizontal, X, Check, Search, Filter, Heart } from 'lucide-react';
import { useCurrency } from '../contexts/CurrencyContext';

const Packages: React.FC = () => {
  const location = useLocation();
  const navigate = useNavigate();
  const { formatPrice } = useCurrency();
  
  const getSearchParams = () => new URLSearchParams(location.search);
  const initialSearch = getSearchParams().get('search') || '';
  
  const [searchTerm, setSearchTerm] = useState(initialSearch);
  const [showMobileFilters, setShowMobileFilters] = useState(false);

  // Filter States
  const [selectedCategories, setSelectedCategories] = useState<string[]>([]);
  const [selectedDurations, setSelectedDurations] = useState<string[]>([]);
  const [maxPrice, setMaxPrice] = useState<number>(10000); // Max Price in USD logic
  const [minRating, setMinRating] = useState<number>(0);

  // Sync search term with URL
  useEffect(() => {
    const params = getSearchParams();
    if (searchTerm) {
      params.set('search', searchTerm);
    } else {
      params.delete('search');
    }
    
    const newSearch = params.toString();
    if (newSearch !== location.search.replace('?', '')) {
        navigate(`?${newSearch}`, { replace: true });
    }
  }, [searchTerm, navigate, location.search]);

  const categories = ['International', 'Domestic', 'Honeymoon', 'Family', 'Adventure'];
  
  const durationOptions = [
    { id: 'short', label: '3 - 5 Days', min: 3, max: 5 },
    { id: 'medium', label: '6 - 10 Days', min: 6, max: 10 },
    { id: 'long', label: '10+ Days', min: 11, max: 100 },
  ];

  const getDurationDays = (str: string): number => {
    const match = str.match(/(\d+)\s*Days?/i);
    return match ? parseInt(match[1], 10) : 0;
  };

  const toggleCategory = (cat: string) => {
    setSelectedCategories(prev => 
      prev.includes(cat) ? prev.filter(c => c !== cat) : [...prev, cat]
    );
  };

  const toggleDuration = (id: string) => {
    setSelectedDurations(prev => 
      prev.includes(id) ? prev.filter(d => d !== id) : [...prev, id]
    );
  };

  const clearFilters = () => {
    setSelectedCategories([]);
    setSelectedDurations([]);
    setMaxPrice(10000);
    setMinRating(0);
    setSearchTerm('');
  };

  const filteredPackages = useMemo(() => {
    return PACKAGES.filter(pkg => {
      // Search Term
      if (searchTerm) {
        const term = searchTerm.toLowerCase();
        if (!pkg.title.toLowerCase().includes(term) && !pkg.location.toLowerCase().includes(term)) {
          return false;
        }
      }

      // Category
      if (selectedCategories.length > 0 && !selectedCategories.includes(pkg.category as any)) {
        return false;
      }

      // Duration
      if (selectedDurations.length > 0) {
        const days = getDurationDays(pkg.duration);
        const match = selectedDurations.some(id => {
          const opt = durationOptions.find(o => o.id === id);
          return opt && days >= opt.min && days <= opt.max;
        });
        if (!match) return false;
      }

      // Price (Slider Logic - uses base USD price)
      if (pkg.price > maxPrice) {
        return false;
      }

      // Rating (Min Stars)
      if (minRating > 0 && pkg.rating < minRating) {
        return false;
      }

      return true;
    });
  }, [searchTerm, selectedCategories, selectedDurations, maxPrice, minRating]);

  const SidebarFilters = () => (
    <div className="space-y-8">
      {/* Header */}
      <div className="flex justify-between items-center pb-4 border-b border-gray-100">
        <h3 className="font-bold text-lg text-blue-900 flex items-center">
          <Filter size={20} className="mr-2 text-blue-600" /> Filters
        </h3>
        <button onClick={clearFilters} className="text-xs text-gray-400 hover:text-red-500 font-medium transition-colors">
          Reset All
        </button>
      </div>

      {/* Search */}
      <div>
        <label className="text-xs font-bold text-gray-500 uppercase tracking-wider mb-3 block">Destination</label>
        <div className="relative group">
          <input
            type="text"
            placeholder="Bali, Dubai, Kerala..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full pl-10 pr-4 py-3 bg-gray-50 border-transparent focus:bg-white border border-gray-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all shadow-sm"
          />
          <Search size={18} className="absolute left-3 top-3.5 text-gray-400 group-focus-within:text-blue-500 transition-colors" />
        </div>
      </div>

      {/* Travel Style (Chips) */}
      <div>
        <label className="text-xs font-bold text-gray-500 uppercase tracking-wider mb-3 block">Travel Style</label>
        <div className="flex flex-wrap gap-2">
          {categories.map(cat => {
            const isSelected = selectedCategories.includes(cat);
            return (
              <button
                key={cat}
                onClick={() => toggleCategory(cat)}
                className={`px-4 py-2 rounded-full text-xs font-semibold transition-all duration-200 border ${
                  isSelected 
                    ? 'bg-blue-600 text-white border-blue-600 shadow-md shadow-blue-200 transform scale-105' 
                    : 'bg-white text-gray-600 border-gray-200 hover:border-blue-300 hover:text-blue-600'
                }`}
              >
                {cat}
              </button>
            );
          })}
        </div>
      </div>

      {/* Price Range (Slider) */}
      <div>
        <div className="flex justify-between items-center mb-4">
             <label className="text-xs font-bold text-gray-500 uppercase tracking-wider">Max Budget</label>
             <span className="text-sm font-bold text-blue-900 bg-blue-50 px-2 py-1 rounded-lg">{formatPrice(maxPrice)}</span>
        </div>
        <div className="px-1">
          <input 
              type="range" 
              min="200" 
              max="10000" 
              step="100" 
              value={maxPrice}
              onChange={(e) => setMaxPrice(parseInt(e.target.value))}
              className="w-full h-2 bg-gray-200 rounded-lg appearance-none cursor-pointer accent-blue-600 hover:accent-blue-500"
          />
        </div>
        <div className="flex justify-between text-[10px] text-gray-400 mt-2 font-medium">
            <span>{formatPrice(200)}</span>
            <span>{formatPrice(10000)}+</span>
        </div>
      </div>

      {/* Duration (Stylized Checkboxes) */}
      <div>
        <label className="text-xs font-bold text-gray-500 uppercase tracking-wider mb-3 block">Duration</label>
        <div className="space-y-2">
          {durationOptions.map(option => {
             const isChecked = selectedDurations.includes(option.id);
             return (
                <div 
                    key={option.id}
                    onClick={() => toggleDuration(option.id)}
                    className={`flex items-center justify-between p-3 rounded-xl cursor-pointer border transition-all duration-200 group ${
                        isChecked 
                        ? 'bg-blue-50 border-blue-200 shadow-sm' 
                        : 'bg-white border-gray-100 hover:border-blue-200 hover:shadow-sm'
                    }`}
                >
                    <div className="flex items-center">
                         <Clock size={16} className={`mr-3 transition-colors ${isChecked ? 'text-blue-600' : 'text-gray-400 group-hover:text-blue-400'}`} />
                         <span className={`text-sm transition-colors ${isChecked ? 'text-blue-900 font-semibold' : 'text-gray-600 group-hover:text-gray-900'}`}>{option.label}</span>
                    </div>
                    <div className={`w-5 h-5 rounded-full border flex items-center justify-center transition-all ${isChecked ? 'bg-blue-600 border-blue-600' : 'border-gray-300 group-hover:border-blue-400'}`}>
                        {isChecked && <Check size={12} className="text-white" />}
                    </div>
                </div>
             );
          })}
        </div>
      </div>

      {/* Rating (Star Interaction) */}
      <div>
        <label className="text-xs font-bold text-gray-500 uppercase tracking-wider mb-3 block">Hotel Rating</label>
        <div className="bg-white p-4 rounded-xl border border-gray-100 shadow-sm">
            <div className="flex items-center justify-between mb-2">
                {[1, 2, 3, 4, 5].map((star) => (
                    <button
                        key={star}
                        onClick={() => setMinRating(star === minRating ? 0 : star)}
                        className="focus:outline-none transform hover:scale-125 transition-transform duration-200 p-1"
                    >
                        <Star 
                            size={22} 
                            className={`transition-colors duration-200 ${
                                star <= minRating 
                                    ? 'fill-amber-400 text-amber-400 drop-shadow-sm' 
                                    : 'fill-gray-50 text-gray-300 hover:text-amber-300'
                            }`} 
                        />
                    </button>
                ))}
            </div>
            <p className="text-xs text-center font-medium text-gray-500 h-4">
                {minRating > 0 ? `${minRating}+ Star Properties` : 'All Ratings'}
            </p>
        </div>
      </div>
    </div>
  );

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-blue-900 py-16 text-center relative overflow-hidden">
         <div className="absolute inset-0 bg-[url('https://images.unsplash.com/photo-1500530855697-b586d89ba3ee?ixlib=rb-4.0.3&auto=format&fit=crop&w=2000&q=80')] bg-cover bg-center opacity-20"></div>
        <div className="relative z-10">
            <h1 className="text-4xl font-bold text-white mb-2 tracking-tight">Tour Packages</h1>
            <p className="text-blue-200 font-medium">Discover your perfect getaway</p>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="flex flex-col lg:flex-row gap-10">
          
          {/* Desktop Sidebar */}
          <div className="hidden lg:block w-72 flex-shrink-0">
             <div className="bg-white p-6 rounded-2xl shadow-lg sticky top-24 border border-gray-100">
               <SidebarFilters />
             </div>
          </div>

          {/* Mobile Filter Toggle */}
          <div className="lg:hidden mb-6 flex justify-between items-center bg-white p-4 rounded-xl shadow-sm">
             <p className="text-gray-700 font-bold">{filteredPackages.length} <span className="font-normal text-gray-500">Packages Found</span></p>
             <button 
              onClick={() => setShowMobileFilters(true)}
              className="flex items-center gap-2 bg-blue-50 border border-blue-100 px-5 py-2.5 rounded-lg text-blue-700 font-bold hover:bg-blue-100 transition-colors"
             >
               <SlidersHorizontal size={18} /> Filters
             </button>
          </div>

          {/* Mobile Filter Modal */}
          {showMobileFilters && (
            <div className="fixed inset-0 z-50 lg:hidden">
               <div className="absolute inset-0 bg-black/60 backdrop-blur-sm transition-opacity" onClick={() => setShowMobileFilters(false)}></div>
               <div className="absolute right-0 top-0 bottom-0 w-80 bg-white shadow-2xl p-6 overflow-y-auto animate-fade-in-left">
                  <div className="flex justify-between items-center mb-8">
                    <h3 className="text-xl font-bold text-blue-900">Filters</h3>
                    <button onClick={() => setShowMobileFilters(false)} className="bg-gray-100 p-2 rounded-full text-gray-500 hover:text-red-500 hover:bg-red-50 transition-all">
                      <X size={20} />
                    </button>
                  </div>
                  <SidebarFilters />
                  <button 
                    onClick={() => setShowMobileFilters(false)}
                    className="w-full mt-8 bg-blue-600 text-white font-bold py-3.5 rounded-xl shadow-lg hover:bg-blue-700 transition-colors"
                  >
                    Show {filteredPackages.length} Results
                  </button>
               </div>
            </div>
          )}

          {/* Package Grid */}
          <div className="flex-1">
            {filteredPackages.length > 0 ? (
               <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                  {filteredPackages.map((pkg) => (
                    <div key={pkg.id} className="bg-white rounded-2xl shadow-md hover:shadow-2xl transition-all duration-300 overflow-hidden group flex flex-col h-full border border-gray-100 hover:border-blue-100">
                        {/* Image */}
                        <div className="relative h-60 overflow-hidden">
                            <img 
                                src={pkg.image} 
                                alt={pkg.title} 
                                className="w-full h-full object-cover transform group-hover:scale-110 transition-transform duration-700"
                                onError={(e) => {
                                    const target = e.target as HTMLImageElement;
                                    target.src = 'https://images.unsplash.com/photo-1590523277543-a94d2e4eb00b?auto=format&fit=crop&w=800&q=80'; // Fallback
                                }}
                            />
                            {/* Wishlist Button */}
                            <button className="absolute top-3 right-3 bg-white/20 backdrop-blur-md hover:bg-white p-2 rounded-full text-white hover:text-red-500 transition-all shadow-sm z-20">
                                <Heart size={18} className="hover:fill-current" />
                            </button>

                            <div className="absolute top-4 left-4 bg-white/95 backdrop-blur-md text-blue-900 text-xs font-bold px-3 py-1 rounded-full shadow-md z-10 border border-gray-100">
                                {pkg.category}
                            </div>
                            <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black/80 via-black/40 to-transparent p-5">
                               <div className="flex items-center text-white text-sm font-medium">
                                   <MapPin size={16} className="mr-1 text-amber-400" /> {pkg.location}
                               </div>
                            </div>
                        </div>

                        {/* Content */}
                        <div className="p-6 flex-1 flex flex-col">
                            <div className="flex justify-between items-start mb-3">
                                <h3 className="text-xl font-bold text-gray-800 leading-tight group-hover:text-blue-700 transition-colors">{pkg.title}</h3>
                                <div className="flex items-center bg-amber-50 px-2 py-1 rounded-lg text-amber-600 text-xs font-bold flex-shrink-0 ml-2 border border-amber-100">
                                    <Star size={12} className="fill-current mr-1" /> {pkg.rating}
                                </div>
                            </div>
                            
                            <div className="flex items-center text-gray-500 text-xs font-medium mb-4">
                                <Clock size={14} className="mr-1.5 text-blue-500" /> {pkg.duration}
                            </div>
                            
                            <p className="text-gray-600 text-sm mb-5 line-clamp-2 flex-1 leading-relaxed">{pkg.description}</p>
                            
                            {/* Tags */}
                            <div className="flex flex-wrap gap-2 mb-6">
                                {pkg.inclusions.slice(0, 3).map((inc, i) => (
                                   <span key={i} className="text-[10px] uppercase tracking-wider text-gray-500 bg-gray-50 border border-gray-100 px-2 py-1 rounded-md font-medium">{inc}</span>
                                ))}
                                {pkg.inclusions.length > 3 && (
                                    <span className="text-[10px] text-gray-400 px-1 py-1">+More</span>
                                )}
                            </div>

                            <div className="pt-5 border-t border-dashed border-gray-200 flex items-center justify-between mt-auto">
                                <div>
                                    <span className="text-xs text-gray-400 block font-medium uppercase tracking-wide">Total Price</span>
                                    <span className="text-2xl font-bold text-blue-900">{formatPrice(pkg.price)}</span>
                                </div>
                                <Link 
                                    to={`/packages/${pkg.id}`}
                                    className="bg-blue-600 hover:bg-blue-700 text-white text-sm font-bold px-6 py-3 rounded-xl transition-all shadow-md hover:shadow-lg transform hover:-translate-y-0.5"
                                >
                                    View Details
                                </Link>
                            </div>
                        </div>
                    </div>
                  ))}
               </div>
            ) : (
              <div className="bg-white rounded-3xl shadow-sm p-16 text-center border border-gray-100">
                 <div className="w-24 h-24 bg-gray-50 rounded-full flex items-center justify-center mx-auto mb-6 text-gray-300">
                    <Search size={40} />
                 </div>
                 <h3 className="text-2xl font-bold text-gray-800 mb-3">No packages found</h3>
                 <p className="text-gray-500 mb-8 max-w-md mx-auto">We couldn't find any trips matching your current filters. Try adjusting your price range or categories.</p>
                 <button 
                    onClick={clearFilters}
                    className="bg-blue-50 hover:bg-blue-100 text-blue-600 font-bold py-3 px-8 rounded-xl transition-colors"
                 >
                   Clear all filters
                 </button>
              </div>
            )}
          </div>

        </div>
      </div>
    </div>
  );
};

export default Packages;
