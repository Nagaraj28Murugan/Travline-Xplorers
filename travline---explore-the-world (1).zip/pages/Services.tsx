import React from 'react';
import { SERVICES } from '../data';
import { Plane, Building, FileText, Shield, Ship, Car } from 'lucide-react';

const iconMap: { [key: string]: React.ElementType } = {
    Plane,
    Building,
    FileText,
    Shield,
    Ship,
    Car
};

const Services: React.FC = () => {
  return (
    <div className="bg-gray-50 min-h-screen">
       {/* Header */}
       <div className="bg-blue-900 py-20 text-center">
        <h1 className="text-4xl font-bold text-white mb-2">Our Services</h1>
        <p className="text-blue-200">Comprehensive travel solutions tailored for you</p>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {SERVICES.map((service) => {
                const IconComponent = iconMap[service.icon];
                return (
                    <div key={service.id} className="bg-white p-8 rounded-xl shadow-md hover:shadow-xl transition-all duration-300 border-b-4 border-transparent hover:border-amber-400 group flex flex-col">
                        <div className="w-16 h-16 bg-blue-50 rounded-2xl flex items-center justify-center mb-6 group-hover:bg-blue-600 transition-colors duration-300">
                            {IconComponent && <IconComponent className="w-8 h-8 text-blue-600 group-hover:text-white transition-colors" />}
                        </div>
                        <h3 className="text-xl font-bold text-blue-900 mb-3">{service.title}</h3>
                        <p className="text-gray-600 leading-relaxed mb-6 flex-grow">{service.description}</p>
                        
                        <div className="pt-4 border-t border-gray-100 w-full">
                            <p className="text-xs font-bold text-gray-400 uppercase mb-3 tracking-wider">Popular with</p>
                            <div className="flex flex-wrap gap-2">
                                {service.partners.map((partner, idx) => (
                                    <span key={idx} className="text-xs bg-gray-100 text-gray-600 px-2 py-1 rounded-md font-medium hover:bg-blue-100 hover:text-blue-700 transition-colors cursor-default">
                                        {partner}
                                    </span>
                                ))}
                            </div>
                        </div>
                    </div>
                );
            })}
        </div>

        {/* Customizable Trip Section */}
        <div className="mt-20 bg-white rounded-2xl shadow-lg overflow-hidden">
            <div className="grid grid-cols-1 lg:grid-cols-2">
                <div className="p-12 flex flex-col justify-center">
                    <h2 className="text-3xl font-bold text-blue-900 mb-4">Customize Your Trip</h2>
                    <p className="text-gray-600 mb-6 text-lg">
                        Not finding what you're looking for? We can build a completely custom itinerary just for you. Tell us your preferences, budget, and dream destinations.
                    </p>
                    <ul className="space-y-3 mb-8">
                        <li className="flex items-center text-gray-700"><div className="w-2 h-2 bg-amber-400 rounded-full mr-3"></div>Personalized Itineraries</li>
                        <li className="flex items-center text-gray-700"><div className="w-2 h-2 bg-amber-400 rounded-full mr-3"></div>Private Transfers</li>
                        <li className="flex items-center text-gray-700"><div className="w-2 h-2 bg-amber-400 rounded-full mr-3"></div>Exclusive Experiences</li>
                    </ul>
                    <button className="bg-blue-600 text-white font-bold py-3 px-8 rounded-full self-start hover:bg-blue-700 transition-colors">
                        Start Planning
                    </button>
                </div>
                <div className="h-64 lg:h-auto relative">
                     <img 
                        src="https://images.unsplash.com/photo-1469854523086-cc02fe5d8800?ixlib=rb-4.0.3&auto=format&fit=crop&w=2021&q=80" 
                        alt="Travel Planning" 
                        className="w-full h-full object-cover"
                    />
                </div>
            </div>
        </div>
      </div>
    </div>
  );
};

export default Services;