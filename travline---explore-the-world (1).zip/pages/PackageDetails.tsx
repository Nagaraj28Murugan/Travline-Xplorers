
import React, { useState } from 'react';
import { Link, useParams } from 'react-router-dom';
import { PACKAGES } from '../data';
import { 
  MapPin, Clock, Check, X as XIcon, Calendar, Users, ChevronDown, ChevronUp, 
  CreditCard, Smartphone, Landmark, Loader, CheckCircle, ShieldCheck, QrCode, Image as ImageIcon,
  Mail, AlertCircle, RefreshCw, XCircle, Download
} from 'lucide-react';
import { useCurrency } from '../contexts/CurrencyContext';
import { generateTransactionEmails } from '../services/gemini';
import { jsPDF } from "jspdf";

const PackageDetails: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const pkg = PACKAGES.find(p => p.id === id);
  const { formatPrice, convertPrice, currency } = useCurrency();
  
  // Accordion state for itinerary
  const [openDay, setOpenDay] = useState<number | null>(1);
  
  // Booking Wizard State
  const [showBooking, setShowBooking] = useState(false);
  const [bookingStep, setBookingStep] = useState<1 | 2 | 3 | 4 | 5>(1); // 1: Details, 2: Payment, 3: Processing, 4: Success, 5: Cancelled
  const [paymentMethod, setPaymentMethod] = useState<'card' | 'upi' | 'netbanking' | 'qr' | 'gpay'>('card');
  const [bookingRef, setBookingRef] = useState('');
  const [isCancelling, setIsCancelling] = useState(false);
  const [emailStatus, setEmailStatus] = useState<'idle' | 'sending' | 'sent'>('idle');
  const [transactionId, setTransactionId] = useState(''); // New state for QR verification
  
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone: '',
    date: '',
    travelers: 2,
  });

  const [errors, setErrors] = useState<{ [key: string]: string }>({});

  // Calculations
  const pricePerPersonUSD = pkg?.price || 0;
  const totalPriceUSD = pricePerPersonUSD * formData.travelers;
  const taxUSD = totalPriceUSD * 0.05; // 5% GST/Tax
  const finalAmountUSD = totalPriceUSD + taxUSD;

  // Formatted Prices
  const formattedPricePerPerson = formatPrice(pricePerPersonUSD);
  const formattedTotalPrice = formatPrice(totalPriceUSD);
  const formattedTax = formatPrice(taxUSD);
  const formattedFinalAmount = formatPrice(finalAmountUSD);

  // UPI / GPay Data
  const upiId = 'sarathinagaraj7@oksbi';
  const payeeName = 'Nagaraj';
  const numericAmount = convertPrice(finalAmountUSD).toFixed(2);
  
  // UPI Intent Link (For GPay / Mobile Apps)
  const upiIntentLink = `upi://pay?pa=${upiId}&pn=${encodeURIComponent(payeeName)}&am=${numericAmount}&cu=${currency}&tn=Booking-${bookingRef || 'Pending'}`;

  // QR Code Generation
  const qrData = encodeURIComponent(`upi://pay?pa=${upiId}&pn=${payeeName}&am=${numericAmount}&cu=${currency}&tn=Booking`);
  const qrUrl = `https://api.qrserver.com/v1/create-qr-code/?size=200x200&data=${qrData}`;


  if (!pkg) {
    return <div className="p-20 text-center text-2xl">Package not found. <Link to="/packages" className="text-blue-600 underline">Go Back</Link></div>;
  }

  const toggleDay = (day: number) => {
      setOpenDay(openDay === day ? null : day);
  };

  const validateForm = () => {
    const newErrors: { [key: string]: string } = {};
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    const phoneRegex = /^\+?[0-9\s-]{10,15}$/; // Allows + and 10-15 digits
    const today = new Date();
    today.setHours(0,0,0,0);

    if (!formData.name.trim() || formData.name.length < 3) {
        newErrors.name = "Name must be at least 3 characters.";
    }

    if (!emailRegex.test(formData.email)) {
        newErrors.email = "Please enter a valid email address.";
    }

    if (!phoneRegex.test(formData.phone.replace(/[\s-]/g, ''))) {
        newErrors.phone = "Enter a valid phone number (10-15 digits).";
    }

    if (!formData.date) {
        newErrors.date = "Travel date is required.";
    } else {
        const selectedDate = new Date(formData.date);
        if (selectedDate < today) {
            newErrors.date = "Travel date cannot be in the past.";
        }
    }

    if (formData.travelers < 1) {
        newErrors.travelers = "At least 1 traveler is required.";
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
    // Clear error when user starts typing
    if (errors[name]) {
        setErrors(prev => ({ ...prev, [name]: '' }));
    }
  };

  const handleTravelersChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    let val = parseInt(e.target.value);
    if (isNaN(val)) val = 0;
    setFormData(prev => ({ ...prev, travelers: val }));
    if (errors.travelers) {
        setErrors(prev => ({ ...prev, travelers: '' }));
    }
  };

  const handleNextStep = (e: React.FormEvent) => {
    e.preventDefault();
    if (validateForm()) {
        setBookingStep(2);
    }
  };

  const processBookingEmails = async (refId: string) => {
    setEmailStatus('sending');
    const paymentMethodLabel = paymentMethod === 'qr' ? 'UPI / QR Scan' : 
                               paymentMethod === 'gpay' ? 'Google Pay' :
                               paymentMethod === 'upi' ? 'UPI / Wallet' :
                               paymentMethod === 'netbanking' ? 'Net Banking' : 'Credit/Debit Card';

    console.group(`[CRM Trigger] New Booking Created - REF: ${refId}`);
    console.log(`%cEvent: Payment Received (${formattedFinalAmount})`, 'color: #10b981; font-weight: bold;');
    
    // Try to get AI generated emails
    const aiEmails = await generateTransactionEmails('BOOKING', {
        customerName: formData.name,
        destination: pkg.location,
        date: formData.date,
        travelers: formData.travelers,
        amount: formattedFinalAmount,
        refId: refId,
        paymentMethod: paymentMethodLabel
    });

    let customerContent = "";
    let companyContent = "";

    if (aiEmails) {
        customerContent = aiEmails.customerEmail;
        companyContent = aiEmails.companyEmail;
    } else {
        // Fallback
        customerContent = `Static Confirmation for ${refId}...`;
        companyContent = `Static Alert for ${refId}...`;
    }

    // --- LOGGING ---
    console.log(`%c[Automation] Sending Customer Confirmation...`, 'color: #3b82f6;');
    console.log(customerContent);

    console.log(`%c[Automation] Sending Operations Alert...`, 'color: #f59e0b;');
    console.log(companyContent);
    
    console.groupEnd();
    setEmailStatus('sent');
  };

  const handlePayment = async () => {
    setBookingStep(3); // Processing
    
    // Generate Booking Ref
    const newRef = `TRV-${Math.floor(100000 + Math.random() * 900000)}`;
    setBookingRef(newRef);

    // Process Emails
    const minDelay = new Promise(resolve => setTimeout(resolve, 2500));
    await Promise.all([processBookingEmails(newRef), minDelay]);

    setBookingStep(4); // Success
  };

  const handleManualEmail = () => {
    const subject = encodeURIComponent(`Booking Confirmation - ${bookingRef}`);
    const body = encodeURIComponent(`
Dear Team,

Here are my booking details:
Booking ID: ${bookingRef}
Name: ${formData.name}
Package: ${pkg.title}
Date: ${formData.date}
Travelers: ${formData.travelers}
Total Paid: ${formattedFinalAmount}

Please send the tickets shortly.
    `);
    window.location.href = `mailto:travline28@gmail.com?subject=${subject}&body=${body}`;
  };

  const handleCancellation = async () => {
      setIsCancelling(true);
      setEmailStatus('sending');
      
      console.group(`[CRM Trigger] Booking Cancellation - REF: ${bookingRef}`);
      console.log(`%cEvent: Cancel Requested by User`, 'color: #ef4444; font-weight: bold;');

      // AI Cancellation Emails
      const aiEmails = await generateTransactionEmails('CANCELLATION', {
        customerName: formData.name,
        destination: pkg.location,
        date: formData.date,
        travelers: formData.travelers,
        amount: formattedFinalAmount,
        refId: bookingRef
      });

      if (aiEmails) {
        console.log(`%c[Automation] Sending Cancellation Notice to Customer...`, 'color: #3b82f6;');
        console.log(aiEmails.customerEmail);
        console.log(`%c[Automation] Sending Refund Request to Ops...`, 'color: #f59e0b;');
        console.log(aiEmails.companyEmail);
      }

      console.groupEnd();
      setEmailStatus('sent');
      setIsCancelling(false);
      setBookingStep(5); // Cancelled
  };

  const handleDownloadReceipt = () => {
    const doc = new jsPDF();
    const pageWidth = doc.internal.pageSize.width;

    // Header Background
    doc.setFillColor(30, 58, 138); // Blue 900
    doc.rect(0, 0, pageWidth, 40, 'F');

    // Company Name
    doc.setFontSize(26);
    doc.setTextColor(255, 255, 255);
    doc.setFont("helvetica", "bold");
    doc.text("TRAVLINE", 20, 25);
    
    doc.setFontSize(10);
    doc.setFont("helvetica", "normal");
    doc.setTextColor(251, 191, 36); // Amber 400
    doc.text("Explore the World", 20, 32);

    // Receipt Title
    doc.setFontSize(18);
    doc.setTextColor(30, 58, 138);
    doc.text("BOOKING RECEIPT", pageWidth - 20, 60, { align: "right" });

    doc.setDrawColor(200);
    doc.line(20, 65, pageWidth - 20, 65);

    // Booking Details (Grid Layout)
    const leftColX = 20;
    const rightColX = 110;
    let yPos = 80;

    // Customer Info
    doc.setFontSize(12);
    doc.setTextColor(100);
    doc.text("Customer Details", leftColX, yPos);
    
    yPos += 10;
    doc.setFontSize(10);
    doc.setTextColor(0);
    doc.text(`Name: ${formData.name}`, leftColX, yPos);
    doc.text(`Email: ${formData.email}`, leftColX, yPos + 7);
    doc.text(`Phone: ${formData.phone}`, leftColX, yPos + 14);

    // Booking Meta
    doc.setFontSize(12);
    doc.setTextColor(100);
    doc.text("Booking Info", rightColX, yPos - 10);

    doc.setFontSize(10);
    doc.setTextColor(0);
    doc.text(`Booking Ref: ${bookingRef}`, rightColX, yPos);
    doc.text(`Date: ${new Date().toLocaleDateString()}`, rightColX, yPos + 7);
    doc.text(`Status: Confirmed`, rightColX, yPos + 14);

    yPos += 30;

    // Package Info Box
    doc.setFillColor(243, 244, 246); // Gray 100
    doc.roundedRect(20, yPos, pageWidth - 40, 60, 3, 3, 'F');

    doc.setFontSize(12);
    doc.setTextColor(30, 58, 138);
    doc.setFont("helvetica", "bold");
    doc.text(pkg?.title || "Package", 30, yPos + 15);
    
    doc.setFontSize(10);
    doc.setFont("helvetica", "normal");
    doc.setTextColor(50);
    doc.text(`Destination: ${pkg?.location}`, 30, yPos + 25);
    doc.text(`Duration: ${pkg?.duration}`, 30, yPos + 32);
    doc.text(`Travel Date: ${formData.date}`, 120, yPos + 25);
    doc.text(`Travelers: ${formData.travelers} Person(s)`, 120, yPos + 32);
    
    doc.text("Inclusions:", 30, yPos + 45);
    doc.setFontSize(9);
    doc.setTextColor(100);
    const inclusionsText = pkg?.inclusions.slice(0, 5).join(', ') || "";
    doc.text(inclusionsText + "...", 30, yPos + 52);

    yPos += 75;

    // Payment Section
    doc.setFontSize(12);
    doc.setTextColor(30, 58, 138);
    doc.setFont("helvetica", "bold");
    doc.text("Payment Summary", 20, yPos);
    
    yPos += 10;
    // Table Header
    doc.setFillColor(229, 231, 235);
    doc.rect(20, yPos, pageWidth - 40, 10, 'F');
    doc.setFontSize(10);
    doc.setTextColor(0);
    doc.text("Description", 25, yPos + 7);
    doc.text("Amount", pageWidth - 25, yPos + 7, { align: "right" });

    // Table Row 1
    yPos += 18;
    doc.setFont("helvetica", "normal");
    doc.text(`Package Cost (x${formData.travelers})`, 25, yPos);
    doc.text(formattedTotalPrice, pageWidth - 25, yPos, { align: "right" });

    // Table Row 2
    yPos += 10;
    doc.text("Taxes & Fees (5%)", 25, yPos);
    doc.text(formattedTax, pageWidth - 25, yPos, { align: "right" });

    // Total Line
    yPos += 5;
    doc.setDrawColor(0);
    doc.line(20, yPos + 5, pageWidth - 20, yPos + 5);
    
    yPos += 15;
    doc.setFontSize(12);
    doc.setFont("helvetica", "bold");
    doc.text("Total Paid", 25, yPos);
    doc.text(formattedFinalAmount, pageWidth - 25, yPos, { align: "right" });

    yPos += 10;
    doc.setFontSize(10);
    doc.setFont("helvetica", "normal");
    doc.setTextColor(100);
    const method = paymentMethod === 'qr' ? 'UPI / QR Scan' : 
                   paymentMethod === 'gpay' ? 'Google Pay' :
                   paymentMethod === 'upi' ? 'UPI' :
                   paymentMethod === 'netbanking' ? 'Net Banking' : 'Card';
    doc.text(`Paid via: ${method}`, pageWidth - 25, yPos, { align: "right" });
    
    if (paymentMethod === 'qr' && transactionId) {
        doc.text(`UTR/Ref: ${transactionId}`, pageWidth - 25, yPos + 5, { align: "right" });
    }


    // Footer
    const footerY = 270;
    doc.setDrawColor(200);
    doc.line(20, footerY, pageWidth - 20, footerY);
    
    doc.setFontSize(9);
    doc.setTextColor(100);
    doc.text("For any support, contact us:", 20, footerY + 10);
    doc.setTextColor(0);
    doc.text("Phone: +91 86675 85449", 20, footerY + 15);
    doc.text("Email: travline28@gmail.com", 20, footerY + 20);
    
    doc.setFontSize(8);
    doc.setTextColor(150);
    doc.text("Thank you for choosing TRAVLINE for your journey!", pageWidth / 2, footerY + 20, { align: "center" });

    doc.save(`TRAVLINE-Receipt-${bookingRef}.pdf`);
  };

  const closeBooking = () => {
    setShowBooking(false);
    setTimeout(() => {
        setBookingStep(1);
        setFormData({ ...formData, travelers: 2, date: '' });
        setErrors({});
        setBookingRef('');
        setEmailStatus('idle');
        setTransactionId('');
    }, 300);
  };

  return (
    <div className="bg-gray-50 min-h-screen pb-20">
      {/* Hero Image */}
      <div className="relative h-[50vh]">
        <img 
            src={pkg.image} 
            alt={pkg.title} 
            className="w-full h-full object-cover" 
            onError={(e) => {
                const target = e.target as HTMLImageElement;
                target.src = 'https://images.unsplash.com/photo-1476514525535-07fb3b4ae5f1?auto=format&fit=crop&w=1600&q=80'; // Fallback
            }}
        />
        <div className="absolute inset-0 bg-gradient-to-t from-black/70 to-transparent"></div>
        <div className="absolute bottom-0 left-0 w-full p-8 md:p-16 text-white">
             <div className="max-w-7xl mx-auto">
                <span className="bg-amber-400 text-blue-900 text-sm font-bold px-3 py-1 rounded-full mb-4 inline-block">{pkg.category}</span>
                <h1 className="text-4xl md:text-5xl font-bold mb-2">{pkg.title}</h1>
                <div className="flex flex-wrap items-center gap-6 text-lg">
                    <span className="flex items-center"><MapPin size={20} className="mr-2 text-amber-400"/> {pkg.location}</span>
                    <span className="flex items-center"><Clock size={20} className="mr-2 text-amber-400"/> {pkg.duration}</span>
                </div>
            </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-10">
            {/* Main Content */}
            <div className="lg:col-span-2 space-y-8">
                
                {/* Overview */}
                <div className="bg-white p-8 rounded-2xl shadow-sm">
                    <h2 className="text-2xl font-bold text-blue-900 mb-4">Overview</h2>
                    <p className="text-gray-600 leading-relaxed">{pkg.description}</p>
                </div>

                {/* Photo Gallery */}
                <div className="bg-white p-8 rounded-2xl shadow-sm">
                    <h2 className="text-2xl font-bold text-blue-900 mb-6 flex items-center">
                        <ImageIcon size={24} className="mr-2 text-amber-500" /> Photo Gallery
                    </h2>
                    <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                        {pkg.gallery.map((img, idx) => (
                            <div key={idx} className="rounded-xl overflow-hidden h-32 md:h-40 cursor-pointer hover:opacity-90 transition-opacity shadow-sm group">
                                <img 
                                    src={img} 
                                    alt={`Gallery ${idx+1}`} 
                                    className="w-full h-full object-cover transform group-hover:scale-110 transition-transform duration-700" 
                                    onError={(e) => {
                                        const target = e.target as HTMLImageElement;
                                        target.src = 'https://images.unsplash.com/photo-1590523277543-a94d2e4eb00b?auto=format&fit=crop&w=400&q=80'; // Fallback
                                    }}
                                />
                            </div>
                        ))}
                    </div>
                </div>

                {/* Itinerary */}
                <div className="bg-white p-8 rounded-2xl shadow-sm">
                    <h2 className="text-2xl font-bold text-blue-900 mb-6">Itinerary</h2>
                    <div className="space-y-4">
                        {pkg.itinerary.map((day) => (
                            <div key={day.day} className="border border-gray-200 rounded-lg overflow-hidden">
                                <button 
                                    onClick={() => toggleDay(day.day)}
                                    className="w-full flex justify-between items-center p-4 bg-gray-50 hover:bg-gray-100 transition-colors text-left"
                                >
                                    <div className="flex items-center">
                                        <span className="bg-blue-600 text-white text-xs font-bold px-2 py-1 rounded mr-3">Day {day.day}</span>
                                        <span className="font-semibold text-gray-800">{day.title}</span>
                                    </div>
                                    {openDay === day.day ? <ChevronUp size={20} className="text-gray-500"/> : <ChevronDown size={20} className="text-gray-500"/>}
                                </button>
                                {openDay === day.day && (
                                    <div className="p-4 bg-white text-gray-600 border-t border-gray-100 animate-fade-in">
                                        {day.description}
                                    </div>
                                )}
                            </div>
                        ))}
                    </div>
                </div>

                {/* Inclusions/Exclusions */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div className="bg-white p-8 rounded-2xl shadow-sm border-t-4 border-green-500">
                        <h3 className="text-lg font-bold text-gray-800 mb-4">Inclusions</h3>
                        <ul className="space-y-2">
                            {pkg.inclusions.map((inc, idx) => (
                                <li key={idx} className="flex items-start text-sm text-gray-600">
                                    <Check size={16} className="text-green-500 mr-2 mt-0.5 flex-shrink-0"/> {inc}
                                </li>
                            ))}
                        </ul>
                    </div>
                     <div className="bg-white p-8 rounded-2xl shadow-sm border-t-4 border-red-500">
                        <h3 className="text-lg font-bold text-gray-800 mb-4">Exclusions</h3>
                        <ul className="space-y-2">
                            {pkg.exclusions.map((exc, idx) => (
                                <li key={idx} className="flex items-start text-sm text-gray-600">
                                    <XIcon size={16} className="text-red-500 mr-2 mt-0.5 flex-shrink-0"/> {exc}
                                </li>
                            ))}
                        </ul>
                    </div>
                </div>
            </div>

            {/* Sidebar Booking Card */}
            <div className="lg:col-span-1">
                <div className="bg-white p-6 rounded-2xl shadow-lg sticky top-24 border border-gray-100">
                    <div className="mb-6">
                        <span className="text-gray-500 text-sm">Starting from</span>
                        <div className="flex items-baseline">
                             <span className="text-4xl font-bold text-blue-900">{formattedPricePerPerson}</span>
                             <span className="text-gray-500 ml-2">/ person</span>
                        </div>
                    </div>

                    <div className="space-y-4 mb-6">
                        <div className="flex items-center text-gray-600 border-b border-gray-100 pb-2">
                            <Calendar size={18} className="mr-3 text-blue-500"/>
                            <span className="text-sm">Multiple dates available</span>
                        </div>
                        <div className="flex items-center text-gray-600 border-b border-gray-100 pb-2">
                            <Users size={18} className="mr-3 text-blue-500"/>
                            <span className="text-sm">Small Group & Private Options</span>
                        </div>
                        <div className="flex items-center text-gray-600 border-b border-gray-100 pb-2">
                            <ShieldCheck size={18} className="mr-3 text-green-600"/>
                            <span className="text-sm">Secure Payment</span>
                        </div>
                    </div>

                    <button 
                        onClick={() => setShowBooking(true)}
                        className="w-full bg-blue-600 hover:bg-blue-700 text-white font-bold py-3 rounded-xl transition-all transform active:scale-95 shadow-md hover:shadow-lg"
                    >
                        Book Now
                    </button>
                    <p className="text-xs text-center text-gray-400 mt-4">Reserve your spot with a secure payment.</p>
                </div>
            </div>
        </div>
      </div>

      {/* Booking & Payment Modal */}
      {showBooking && (
          <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm px-4">
              <div className="bg-white rounded-2xl shadow-2xl w-full max-w-lg overflow-hidden relative animate-fade-in-up flex flex-col max-h-[90vh]">
                  
                  {/* Modal Header */}
                  <div className={`p-4 flex justify-between items-center flex-shrink-0 transition-colors ${bookingStep === 5 ? 'bg-red-600' : 'bg-blue-900'}`}>
                      <h3 className="text-xl font-bold text-white flex items-center">
                          {bookingStep === 1 && "1. Traveler Details"}
                          {bookingStep === 2 && "2. Payment"}
                          {bookingStep === 3 && "Processing..."}
                          {bookingStep === 4 && "Booking Confirmed"}
                          {bookingStep === 5 && "Booking Cancelled"}
                      </h3>
                      <button onClick={closeBooking} className="text-blue-200 hover:text-white">
                          <XIcon size={24} />
                      </button>
                  </div>

                  {/* Modal Content */}
                  <div className="p-6 overflow-y-auto flex-grow">
                      
                      {/* Step 1: Details Form */}
                      {bookingStep === 1 && (
                          <form className="space-y-5" onSubmit={handleNextStep}>
                              <div className="bg-amber-50 p-4 rounded-xl mb-6 flex items-start border border-amber-200 shadow-sm">
                                  <img src={pkg.image} alt="thumb" className="w-20 h-20 rounded-lg object-cover mr-4 shadow-sm" />
                                  <div>
                                      <h4 className="font-bold text-gray-900 text-lg">{pkg.title}</h4>
                                      <p className="text-sm text-gray-600 mb-1">{pkg.duration}</p>
                                      <p className="text-sm font-bold text-amber-600 bg-amber-100 px-2 py-0.5 rounded-md inline-block border border-amber-200">{formattedPricePerPerson} <span className="text-gray-500 font-normal">/ person</span></p>
                                  </div>
                              </div>

                              <div>
                                  <label className="block text-xs font-bold text-gray-500 uppercase tracking-wider mb-1.5 ml-1">Full Name</label>
                                  <input 
                                    type="text" 
                                    name="name"
                                    value={formData.name}
                                    onChange={handleInputChange}
                                    className={`w-full bg-gray-50 border rounded-xl p-3.5 outline-none transition-all ${errors.name ? 'border-red-500 focus:ring-2 focus:ring-red-400' : 'border-gray-200 focus:bg-white focus:ring-2 focus:ring-amber-400 focus:border-amber-400'}`}
                                    placeholder="e.g. John Doe"
                                  />
                                  {errors.name && <p className="text-red-500 text-xs mt-1 ml-1 flex items-center"><AlertCircle size={10} className="mr-1"/> {errors.name}</p>}
                              </div>
                              <div className="grid grid-cols-2 gap-4">
                                  <div>
                                    <label className="block text-xs font-bold text-gray-500 uppercase tracking-wider mb-1.5 ml-1">Email</label>
                                    <input 
                                        type="email" 
                                        name="email"
                                        value={formData.email}
                                        onChange={handleInputChange}
                                        className={`w-full bg-gray-50 border rounded-xl p-3.5 outline-none transition-all ${errors.email ? 'border-red-500 focus:ring-2 focus:ring-red-400' : 'border-gray-200 focus:bg-white focus:ring-2 focus:ring-amber-400 focus:border-amber-400'}`}
                                        placeholder="email@example.com"
                                    />
                                    {errors.email && <p className="text-red-500 text-xs mt-1 ml-1 flex items-center"><AlertCircle size={10} className="mr-1"/> {errors.email}</p>}
                                  </div>
                                  <div>
                                    <label className="block text-xs font-bold text-gray-500 uppercase tracking-wider mb-1.5 ml-1">Phone</label>
                                    <input 
                                        type="tel" 
                                        name="phone"
                                        value={formData.phone}
                                        onChange={handleInputChange}
                                        className={`w-full bg-gray-50 border rounded-xl p-3.5 outline-none transition-all ${errors.phone ? 'border-red-500 focus:ring-2 focus:ring-red-400' : 'border-gray-200 focus:bg-white focus:ring-2 focus:ring-amber-400 focus:border-amber-400'}`}
                                        placeholder="+1 234 567 890"
                                    />
                                    {errors.phone && <p className="text-red-500 text-xs mt-1 ml-1 flex items-center"><AlertCircle size={10} className="mr-1"/> {errors.phone}</p>}
                                  </div>
                              </div>
                              <div className="grid grid-cols-2 gap-4">
                                  <div>
                                     <label className="block text-xs font-bold text-gray-500 uppercase tracking-wider mb-1.5 ml-1">Travel Date</label>
                                     <input 
                                        type="date" 
                                        name="date"
                                        value={formData.date}
                                        onChange={handleInputChange}
                                        className={`w-full bg-gray-50 border rounded-xl p-3.5 outline-none transition-all ${errors.date ? 'border-red-500 focus:ring-2 focus:ring-red-400' : 'border-gray-200 focus:bg-white focus:ring-2 focus:ring-amber-400 focus:border-amber-400'}`}
                                    />
                                    {errors.date && <p className="text-red-500 text-xs mt-1 ml-1 flex items-center"><AlertCircle size={10} className="mr-1"/> {errors.date}</p>}
                                  </div>
                                  <div>
                                     <label className="block text-xs font-bold text-gray-500 uppercase tracking-wider mb-1.5 ml-1">Travelers</label>
                                     <input 
                                        type="number" 
                                        name="travelers"
                                        min="1" 
                                        value={formData.travelers}
                                        onChange={handleTravelersChange}
                                        className={`w-full bg-gray-50 border rounded-xl p-3.5 outline-none transition-all ${errors.travelers ? 'border-red-500 focus:ring-2 focus:ring-red-400' : 'border-gray-200 focus:bg-white focus:ring-2 focus:ring-amber-400 focus:border-amber-400'}`}
                                    />
                                    {errors.travelers && <p className="text-red-500 text-xs mt-1 ml-1 flex items-center"><AlertCircle size={10} className="mr-1"/> {errors.travelers}</p>}
                                  </div>
                              </div>
                              
                              <button type="submit" className="w-full bg-gradient-to-r from-amber-400 to-amber-500 hover:from-amber-500 hover:to-amber-600 text-blue-900 font-bold py-4 rounded-xl mt-6 shadow-lg shadow-amber-200/50 flex justify-center items-center transition-all transform hover:scale-[1.01]">
                                  Proceed to Payment
                              </button>
                          </form>
                      )}

                      {/* Step 2: Payment */}
                      {bookingStep === 2 && (
                          <div className="space-y-6">
                              {/* Order Summary */}
                              <div className="bg-gray-50 p-4 rounded-lg border border-gray-200">
                                  <h4 className="font-bold text-gray-800 mb-3 border-b border-gray-200 pb-2">Order Summary</h4>
                                  <div className="flex justify-between text-sm text-gray-600 mb-1">
                                      <span>Package Cost ({formData.travelers} x {formattedPricePerPerson})</span>
                                      <span>{formattedTotalPrice}</span>
                                  </div>
                                  <div className="flex justify-between text-sm text-gray-600 mb-3">
                                      <span>Taxes & Fees (5%)</span>
                                      <span>{formattedTax}</span>
                                  </div>
                                  <div className="flex justify-between text-lg font-bold text-blue-900 border-t border-gray-200 pt-2">
                                      <span>Total Payable</span>
                                      <span>{formattedFinalAmount}</span>
                                  </div>
                              </div>

                              {/* Payment Methods */}
                              <div>
                                  <h4 className="font-bold text-gray-800 mb-3">Select Payment Method</h4>
                                  <div className="space-y-3">
                                      {/* GPay */}
                                      <label className={`flex items-center p-3 border rounded-lg cursor-pointer transition-all ${paymentMethod === 'gpay' ? 'border-blue-600 bg-blue-50' : 'border-gray-300 hover:border-gray-400'}`}>
                                          <input 
                                            type="radio" 
                                            name="payment" 
                                            className="hidden" 
                                            checked={paymentMethod === 'gpay'} 
                                            onChange={() => setPaymentMethod('gpay')} 
                                          />
                                          <div className="bg-white p-2 rounded border border-gray-200 mr-3">
                                              {/* Simple GPay-like Icon */}
                                              <div className="flex items-center space-x-0.5">
                                                  <span className="text-blue-500 font-bold text-lg">G</span>
                                                  <span className="text-green-500 font-bold text-lg">Pay</span>
                                              </div>
                                          </div>
                                          <span className="font-medium text-gray-700">Google Pay</span>
                                      </label>

                                      {/* Credit Card */}
                                      <label className={`flex items-center p-3 border rounded-lg cursor-pointer transition-all ${paymentMethod === 'card' ? 'border-blue-600 bg-blue-50' : 'border-gray-300 hover:border-gray-400'}`}>
                                          <input 
                                            type="radio" 
                                            name="payment" 
                                            className="hidden" 
                                            checked={paymentMethod === 'card'} 
                                            onChange={() => setPaymentMethod('card')} 
                                          />
                                          <div className="bg-white p-2 rounded border border-gray-200 mr-3 text-blue-600">
                                              <CreditCard size={20} />
                                          </div>
                                          <span className="font-medium text-gray-700">Credit / Debit Card</span>
                                      </label>

                                      {/* UPI */}
                                      <label className={`flex items-center p-3 border rounded-lg cursor-pointer transition-all ${paymentMethod === 'upi' ? 'border-blue-600 bg-blue-50' : 'border-gray-300 hover:border-gray-400'}`}>
                                          <input 
                                            type="radio" 
                                            name="payment" 
                                            className="hidden" 
                                            checked={paymentMethod === 'upi'} 
                                            onChange={() => setPaymentMethod('upi')} 
                                          />
                                          <div className="bg-white p-2 rounded border border-gray-200 mr-3 text-green-600">
                                              <Smartphone size={20} />
                                          </div>
                                          <span className="font-medium text-gray-700">UPI ID (PhonePe, Paytm)</span>
                                      </label>

                                      {/* QR Code */}
                                      <label className={`flex items-center p-3 border rounded-lg cursor-pointer transition-all ${paymentMethod === 'qr' ? 'border-blue-600 bg-blue-50' : 'border-gray-300 hover:border-gray-400'}`}>
                                          <input 
                                            type="radio" 
                                            name="payment" 
                                            className="hidden" 
                                            checked={paymentMethod === 'qr'} 
                                            onChange={() => setPaymentMethod('qr')} 
                                          />
                                          <div className="bg-white p-2 rounded border border-gray-200 mr-3 text-gray-800">
                                              <QrCode size={20} />
                                          </div>
                                          <span className="font-medium text-gray-700">Scan QR Code</span>
                                      </label>

                                      {/* Net Banking */}
                                      <label className={`flex items-center p-3 border rounded-lg cursor-pointer transition-all ${paymentMethod === 'netbanking' ? 'border-blue-600 bg-blue-50' : 'border-gray-300 hover:border-gray-400'}`}>
                                          <input 
                                            type="radio" 
                                            name="payment" 
                                            className="hidden" 
                                            checked={paymentMethod === 'netbanking'} 
                                            onChange={() => setPaymentMethod('netbanking')} 
                                          />
                                          <div className="bg-white p-2 rounded border border-gray-200 mr-3 text-purple-600">
                                              <Landmark size={20} />
                                          </div>
                                          <span className="font-medium text-gray-700">Net Banking</span>
                                      </label>
                                  </div>
                              </div>

                              {/* Dynamic Payment Fields */}
                              <div className="bg-white border border-gray-200 rounded-lg p-4 animate-fade-in">
                                  {paymentMethod === 'gpay' && (
                                      <div className="text-center">
                                          <p className="text-sm text-gray-600 mb-4">Click below to pay securely via Google Pay or any UPI app.</p>
                                          {/* Mobile Intent Link */}
                                          <a 
                                            href={upiIntentLink}
                                            className="hidden md:hidden lg:hidden" // Only show on mobile effectively if logic allowed, but we'll use the button below to simulate
                                            id="upi-link"
                                          >
                                              Hidden Link
                                          </a>
                                      </div>
                                  )}
                                  {paymentMethod === 'card' && (
                                      <div className="space-y-3">
                                          <input type="text" placeholder="Card Number" className="w-full border border-gray-300 rounded p-2 text-sm outline-none focus:border-blue-500" />
                                          <div className="flex gap-3">
                                              <input type="text" placeholder="MM/YY" className="w-1/2 border border-gray-300 rounded p-2 text-sm outline-none focus:border-blue-500" />
                                              <input type="text" placeholder="CVV" className="w-1/2 border border-gray-300 rounded p-2 text-sm outline-none focus:border-blue-500" />
                                          </div>
                                          <input type="text" placeholder="Card Holder Name" className="w-full border border-gray-300 rounded p-2 text-sm outline-none focus:border-blue-500" />
                                      </div>
                                  )}
                                  {paymentMethod === 'upi' && (
                                      <div>
                                          <input type="text" placeholder="Enter UPI ID (e.g. name@bank)" className="w-full border border-gray-300 rounded p-2 text-sm outline-none focus:border-blue-500" />
                                      </div>
                                  )}
                                  {paymentMethod === 'qr' && (
                                      <div className="flex flex-col items-center justify-center p-4">
                                          <div className="bg-white p-2 rounded-lg shadow-sm border border-gray-200 mb-2">
                                             <img src={qrUrl} alt="UPI QR Code" className="w-48 h-48" />
                                          </div>
                                          <p className="text-sm font-bold text-gray-700">Scan to pay with any UPI app</p>
                                          <p className="text-xs text-gray-500 mt-1">UPI ID: {upiId}</p>
                                          
                                          {/* New Input for Transaction ID verification */}
                                          <div className="w-full mt-4 text-left">
                                              <label className="block text-xs font-bold text-gray-500 uppercase tracking-wider mb-1.5">Transaction ID / UTR</label>
                                              <input 
                                                  type="text" 
                                                  placeholder="Enter 12-digit UTR number"
                                                  className="w-full border border-gray-300 rounded p-2 text-sm outline-none focus:border-blue-500"
                                                  value={transactionId}
                                                  onChange={(e) => setTransactionId(e.target.value)}
                                              />
                                              <p className="text-[10px] text-gray-400 mt-1">Please enter the UTR/Reference number from your payment app to verify.</p>
                                          </div>
                                      </div>
                                  )}
                                  {paymentMethod === 'netbanking' && (
                                      <select className="w-full border border-gray-300 rounded p-2 text-sm outline-none focus:border-blue-500 bg-white">
                                          <option>Select Bank</option>
                                          <option>HDFC Bank</option>
                                          <option>ICICI Bank</option>
                                          <option>SBI</option>
                                          <option>Axis Bank</option>
                                      </select>
                                  )}
                              </div>

                              <button 
                                onClick={() => {
                                    if (paymentMethod === 'gpay') {
                                        // On mobile this works, on desktop it does nothing/errors or opens handler
                                        window.location.href = upiIntentLink;
                                        // We also proceed to 'processing' simulation for UX
                                        setTimeout(handlePayment, 1000); 
                                    } else {
                                        handlePayment();
                                    }
                                }} 
                                disabled={paymentMethod === 'qr' && !transactionId.trim()}
                                className={`w-full font-bold py-3.5 rounded-xl shadow-lg transition-all text-white ${
                                    paymentMethod === 'gpay' 
                                    ? 'bg-black hover:bg-gray-900 border border-gray-800' 
                                    : (paymentMethod === 'qr' && !transactionId.trim())
                                        ? 'bg-gray-300 cursor-not-allowed'
                                        : 'bg-blue-600 hover:bg-blue-700'
                                }`}
                              >
                                {paymentMethod === 'qr' ? 'Verify Payment' : 
                                 paymentMethod === 'gpay' ? (
                                     <div className="flex items-center justify-center space-x-1">
                                         <span>Pay with</span>
                                         <span className="font-bold">G</span>
                                         <span className="font-bold">Pay</span>
                                     </div>
                                 ) : 
                                 `Pay ${formattedFinalAmount}`}
                              </button>
                          </div>
                      )}

                      {/* Step 3: Processing */}
                      {bookingStep === 3 && (
                        <div className="flex flex-col items-center justify-center h-full py-10">
                           <Loader size={60} className="text-amber-400 animate-spin mb-6" />
                           <h3 className="text-2xl font-bold text-blue-900 mb-2">Processing Payment...</h3>
                           <p className="text-gray-500 text-center max-w-xs">
                             Please do not close this window. We are securing your booking and generating confirmation details.
                           </p>
                           {emailStatus === 'sending' && (
                               <p className="text-sm text-blue-500 mt-4 animate-pulse">Sending confirmation emails...</p>
                           )}
                        </div>
                      )}

                      {/* Step 4: Success */}
                      {bookingStep === 4 && (
                          <div className="text-center py-6">
                              <div className="w-20 h-20 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-6">
                                  <CheckCircle size={40} className="text-green-600" />
                              </div>
                              <h3 className="text-2xl font-bold text-blue-900 mb-2">Booking Confirmed!</h3>
                              <p className="text-gray-600 mb-6">Thank you for booking with TRAVLINE.</p>
                              
                              <div className="bg-gray-50 p-4 rounded-xl border border-gray-200 mb-6 inline-block w-full text-left">
                                  <div className="flex justify-between items-center border-b border-gray-200 pb-2 mb-2">
                                      <span className="text-sm text-gray-500">Booking ID</span>
                                      <span className="font-mono font-bold text-blue-900 text-lg">{bookingRef}</span>
                                  </div>
                                  <div className="flex justify-between items-center mb-1">
                                      <span className="text-sm text-gray-500">Amount Paid</span>
                                      <span className="font-bold text-gray-800">{formattedFinalAmount}</span>
                                  </div>
                                  <div className="flex justify-between items-center">
                                      <span className="text-sm text-gray-500">Travel Date</span>
                                      <span className="font-bold text-gray-800">{formData.date}</span>
                                  </div>
                              </div>
                              
                              <div className="flex items-center justify-center gap-2 text-sm text-green-600 bg-green-50 p-3 rounded-lg border border-green-100 mb-8">
                                  <Mail size={16} />
                                  <span>Confirmation emails sent to you and admin.</span>
                              </div>

                              <div className="flex flex-col gap-3">
                                  <button onClick={handleDownloadReceipt} className="w-full bg-blue-600 hover:bg-blue-700 text-white font-bold py-3 rounded-xl transition-colors flex items-center justify-center gap-2">
                                      <Download size={18} /> Download Receipt (PDF)
                                  </button>
                                  <button onClick={handleManualEmail} className="w-full bg-amber-100 hover:bg-amber-200 text-amber-900 font-bold py-3 rounded-xl transition-colors flex items-center justify-center gap-2">
                                      <Mail size={18} /> Email Booking Details
                                  </button>
                                  <button 
                                    onClick={handleCancellation}
                                    className="w-full text-red-500 hover:text-red-700 font-medium py-3 rounded-xl transition-colors text-sm hover:bg-red-50"
                                  >
                                      Cancel Booking
                                  </button>
                                  <button onClick={closeBooking} className="w-full bg-gray-100 hover:bg-gray-200 text-gray-600 font-bold py-3 rounded-xl transition-colors">
                                      Close
                                  </button>
                              </div>
                          </div>
                      )}

                      {/* Step 5: Cancelled */}
                      {bookingStep === 5 && (
                          <div className="text-center py-6">
                              {isCancelling ? (
                                  <div className="flex flex-col items-center">
                                      <Loader size={40} className="text-red-500 animate-spin mb-4" />
                                      <p className="text-red-500">Processing Cancellation...</p>
                                  </div>
                              ) : (
                                  <>
                                    <div className="w-20 h-20 bg-red-100 rounded-full flex items-center justify-center mx-auto mb-6">
                                        <XCircle size={40} className="text-red-600" />
                                    </div>
                                    <h3 className="text-2xl font-bold text-red-700 mb-2">Booking Cancelled</h3>
                                    <p className="text-gray-600 mb-6">Your booking <strong>{bookingRef}</strong> has been cancelled.</p>
                                    
                                    <div className="bg-red-50 p-4 rounded-xl border border-red-100 mb-8 text-left">
                                        <h4 className="font-bold text-red-800 mb-2 flex items-center"><AlertCircle size={16} className="mr-2"/> Refund Initiated</h4>
                                        <p className="text-sm text-red-700">
                                            A full refund of <strong>{formattedFinalAmount}</strong> has been initiated to your original payment method. It may take 5-7 business days to reflect in your account.
                                        </p>
                                    </div>

                                    <div className="flex items-center justify-center gap-2 text-sm text-gray-500 mb-6">
                                        <Mail size={16} />
                                        <span>Cancellation notice sent to email.</span>
                                    </div>

                                    <button onClick={closeBooking} className="w-full bg-gray-200 hover:bg-gray-300 text-gray-800 font-bold py-3 rounded-xl transition-colors">
                                        Close
                                    </button>
                                  </>
                              )}
                          </div>
                      )}
                  </div>
              </div>
          </div>
      )}
    </div>
  );
};

export default PackageDetails;
