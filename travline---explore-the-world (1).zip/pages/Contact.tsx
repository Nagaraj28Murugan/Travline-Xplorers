
import React from 'react';
import { MapPin, Phone, Mail, Send } from 'lucide-react';

const Contact: React.FC = () => {
  return (
    <div className="bg-gray-50 min-h-screen">
       {/* Header */}
       <div className="bg-blue-900 py-20 text-center">
        <h1 className="text-4xl font-bold text-white mb-2">Contact Us</h1>
        <p className="text-blue-200">We'd love to hear from you</p>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
            
            {/* Contact Form */}
            <div className="bg-white p-8 md:p-10 rounded-2xl shadow-lg">
                <h2 className="text-2xl font-bold text-blue-900 mb-6">Send us a message</h2>
                <form className="space-y-6">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                        <div>
                            <label className="block text-sm font-medium text-gray-700 mb-1">First Name</label>
                            <input type="text" className="w-full border-gray-300 rounded-lg shadow-sm focus:ring-blue-500 focus:border-blue-500 p-3 border" placeholder="John" />
                        </div>
                        <div>
                            <label className="block text-sm font-medium text-gray-700 mb-1">Last Name</label>
                            <input type="text" className="w-full border-gray-300 rounded-lg shadow-sm focus:ring-blue-500 focus:border-blue-500 p-3 border" placeholder="Doe" />
                        </div>
                    </div>
                    <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1">Email Address</label>
                        <input type="email" className="w-full border-gray-300 rounded-lg shadow-sm focus:ring-blue-500 focus:border-blue-500 p-3 border" placeholder="john@example.com" />
                    </div>
                     <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1">Phone Number</label>
                        <input type="tel" className="w-full border-gray-300 rounded-lg shadow-sm focus:ring-blue-500 focus:border-blue-500 p-3 border" placeholder="+1 (555) 000-0000" />
                    </div>
                    <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1">Message</label>
                        <textarea rows={4} className="w-full border-gray-300 rounded-lg shadow-sm focus:ring-blue-500 focus:border-blue-500 p-3 border" placeholder="Tell us about your travel plans..."></textarea>
                    </div>
                    <button type="submit" className="w-full flex items-center justify-center bg-blue-600 hover:bg-blue-700 text-white font-bold py-3 rounded-lg transition-colors">
                        Send Message <Send size={18} className="ml-2" />
                    </button>
                </form>
            </div>

            {/* Contact Info */}
            <div className="space-y-8">
                {/* Info Cards */}
                <div className="grid grid-cols-1 gap-6">
                     <div className="bg-white p-6 rounded-xl shadow-md flex items-start">
                        <div className="bg-blue-100 p-3 rounded-full mr-4">
                            <MapPin className="text-blue-600 w-6 h-6" />
                        </div>
                        <div>
                            <h3 className="font-bold text-gray-800 mb-1">Visit Us</h3>
                            <p className="text-gray-600">42 Bharathiyar street, Vengamedu<br/>Karur 639006, Tamilnadu, India</p>
                        </div>
                     </div>
                     
                     <div className="bg-white p-6 rounded-xl shadow-md flex items-start">
                        <div className="bg-blue-100 p-3 rounded-full mr-4">
                            <Phone className="text-blue-600 w-6 h-6" />
                        </div>
                        <div>
                            <h3 className="font-bold text-gray-800 mb-1">Call Us</h3>
                            <p className="text-gray-600">+91 86675 85449</p>
                            <p className="text-sm text-green-600 font-medium mt-1">Available 24/7</p>
                        </div>
                     </div>

                     <div className="bg-white p-6 rounded-xl shadow-md flex items-start">
                        <div className="bg-blue-100 p-3 rounded-full mr-4">
                            <Mail className="text-blue-600 w-6 h-6" />
                        </div>
                        <div>
                            <h3 className="font-bold text-gray-800 mb-1">Email Us</h3>
                            <p className="text-gray-600">travline28@gmail.com<br/>support@travline.com</p>
                        </div>
                     </div>
                </div>
            </div>
        </div>
      </div>
    </div>
  );
};

export default Contact;
