import React from 'react';
import { Shield, Heart, Globe, Award } from 'lucide-react';

const About: React.FC = () => {
  return (
    <div className="bg-white">
      {/* Header */}
      <div className="bg-blue-900 py-20 text-center">
        <h1 className="text-4xl font-bold text-white mb-2">About Us</h1>
        <p className="text-blue-200">Our story, mission, and values</p>
      </div>

      {/* Main Content */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center mb-20">
            <div>
                <img 
                    src="https://images.unsplash.com/photo-1522202176988-66273c2fd55f?ixlib=rb-4.0.3&auto=format&fit=crop&w=1471&q=80" 
                    alt="Team Meeting" 
                    className="rounded-2xl shadow-2xl"
                />
            </div>
            <div>
                <h2 className="text-3xl font-bold text-blue-900 mb-6">Exploring the World Since 2025</h2>
                <p className="text-gray-600 mb-4 leading-relaxed">
                    TRAVLINE began with a simple idea: to make travel accessible, seamless, and unforgettable for everyone. Established in 2025, we are a modern, tech-forward travel partner dedicated to curating exceptional journeys for adventurers around the globe.
                </p>
                <p className="text-gray-600 mb-6 leading-relaxed">
                    We believe that travel is not just about visiting new places, but about connecting with cultures, people, and nature. Our team of expert travel consultants works tirelessly to curate personalized itineraries that suit your dreams and budget.
                </p>
                
                <div className="grid grid-cols-2 gap-6">
                    <div className="border-l-4 border-amber-400 pl-4">
                        <p className="text-3xl font-bold text-blue-900">10k+</p>
                        <p className="text-sm text-gray-500">Happy Travelers</p>
                    </div>
                    <div className="border-l-4 border-amber-400 pl-4">
                        <p className="text-3xl font-bold text-blue-900">50+</p>
                        <p className="text-sm text-gray-500">Destinations</p>
                    </div>
                </div>
            </div>
        </div>

        {/* Mission & Vision */}
        <div className="bg-gray-50 rounded-2xl p-8 md:p-12 mb-20">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-12">
                <div>
                    <h3 className="text-2xl font-bold text-blue-900 mb-4">Our Mission</h3>
                    <p className="text-gray-600">
                        To provide exceptional travel experiences by offering personalized services, maintaining high standards of quality, and promoting sustainable tourism practices that benefit local communities.
                    </p>
                </div>
                <div>
                    <h3 className="text-2xl font-bold text-blue-900 mb-4">Our Vision</h3>
                    <p className="text-gray-600">
                        To be the world's most trusted and innovative travel management company, inspiring people to explore the beauty of our planet while fostering global connection and understanding.
                    </p>
                </div>
            </div>
        </div>

        {/* Core Values */}
        <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-blue-900 mb-2">Our Core Values</h2>
            <div className="h-1 w-20 bg-amber-400 mx-auto mb-12"></div>
            
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8">
                <div className="text-center group">
                    <div className="w-20 h-20 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-4 group-hover:bg-blue-600 transition-colors duration-300">
                        <Shield className="w-10 h-10 text-blue-600 group-hover:text-white transition-colors" />
                    </div>
                    <h4 className="text-xl font-bold text-gray-800 mb-2">Trust</h4>
                    <p className="text-sm text-gray-500">Transparency and reliability in every booking.</p>
                </div>
                <div className="text-center group">
                    <div className="w-20 h-20 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-4 group-hover:bg-blue-600 transition-colors duration-300">
                        <Award className="w-10 h-10 text-blue-600 group-hover:text-white transition-colors" />
                    </div>
                    <h4 className="text-xl font-bold text-gray-800 mb-2">Quality</h4>
                    <p className="text-sm text-gray-500">Premium services and top-rated accommodations.</p>
                </div>
                <div className="text-center group">
                    <div className="w-20 h-20 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-4 group-hover:bg-blue-600 transition-colors duration-300">
                        <Heart className="w-10 h-10 text-blue-600 group-hover:text-white transition-colors" />
                    </div>
                    <h4 className="text-xl font-bold text-gray-800 mb-2">Passion</h4>
                    <p className="text-sm text-gray-500">We love what we do and it shows in our work.</p>
                </div>
                <div className="text-center group">
                    <div className="w-20 h-20 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-4 group-hover:bg-blue-600 transition-colors duration-300">
                        <Globe className="w-10 h-10 text-blue-600 group-hover:text-white transition-colors" />
                    </div>
                    <h4 className="text-xl font-bold text-gray-800 mb-2">Sustainability</h4>
                    <p className="text-sm text-gray-500">Committed to responsible and eco-friendly tourism.</p>
                </div>
            </div>
        </div>
      </div>
    </div>
  );
};

export default About;