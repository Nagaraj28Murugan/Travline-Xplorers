
import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { Search, Calendar, MapPin, Star, ArrowRight, CheckCircle, Users, Headphones } from 'lucide-react';
import { PACKAGES, TESTIMONIALS } from '../data';
import ParticlesBackground from '../components/ParticlesBackground';
import { useCurrency } from '../contexts/CurrencyContext';

const Home: React.FC = () => {
  const { formatPrice } = useCurrency();

  const [searchDest, setSearchDest] = useState('');
  const [searchDate, setSearchDate] = useState('');

  return (
    <div>
      {/* Hero Section */}
      <section className="relative h-[600px] flex items-center justify-center overflow-hidden">
        {/* Background Image & Overlay */}
        <div className="absolute inset-0 z-0">
          <img 
            src="https://images.unsplash.com/photo-1436491865332-7a61a109cc05?ixlib=rb-4.0.3&auto=format&fit=crop&w=2074&q=80" 
            alt="Modern Travel - Airplane in Blue Sky" 
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-r from-blue-900/50 via-blue-900/30 to-transparent"></div>
        </div>

        {/* Moving Particles Theme */}
        <div className="absolute inset-0 z-0 pointer-events-none">
            <ParticlesBackground />
        </div>
        
        <div className="relative z-10 text-center px-4 max-w-4xl mx-auto">
          <h1 className="text-4xl md:text-6xl font-bold text-white mb-4 tracking-wide animate-fade-in-down drop-shadow-lg">
            Explore the World with <span className="text-amber-400">Travline</span>
          </h1>
          <p className="text-lg md:text-xl text-blue-100 mb-8 animate-fade-in-up drop-shadow-md font-medium">
            Discover breathtaking destinations and create memories that last a lifetime.
          </p>

          {/* Search Box */}
          <div className="bg-white/95 backdrop-blur-sm p-4 rounded-xl shadow-2xl max-w-3xl mx-auto flex flex-col md:flex-row gap-4 animate-fade-in-up">
            <div className="flex-1 flex items-center border-b md:border-b-0 md:border-r border-gray-200 px-2">
              <MapPin className="text-blue-500 mr-2" size={20} />
              <input 
                type="text" 
                placeholder="Where to?" 
                className="w-full p-2 outline-none text-gray-700 placeholder-gray-400 bg-transparent"
                value={searchDest}
                onChange={(e) => setSearchDest(e.target.value)}
              />
            </div>
            <div className="flex-1 flex items-center border-b md:border-b-0 md:border-r border-gray-200 px-2">
              <Calendar className="text-blue-500 mr-2" size={20} />
              <input 
                type="date" 
                className="w-full p-2 outline-none text-gray-700 placeholder-gray-400 bg-transparent"
                value={searchDate}
                onChange={(e) => setSearchDate(e.target.value)}
              />
            </div>
            <div className="md:w-40">
              <Link 
                to={`/packages?search=${searchDest}&date=${searchDate}`} 
                className="flex items-center justify-center w-full bg-blue-600 hover:bg-blue-700 text-white font-bold py-3 rounded-lg transition-colors shadow-md"
              >
                Search
              </Link>
            </div>
          </div>
        </div>
      </section>

      {/* Why Choose Us */}
      <section className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-blue-900 mb-2">Why Choose TRAVLINE?</h2>
            <div className="h-1 w-20 bg-amber-400 mx-auto"></div>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="p-6 bg-blue-50 rounded-xl text-center hover:shadow-lg transition-shadow">
              <div className="w-16 h-16 bg-blue-100 text-blue-600 rounded-full flex items-center justify-center mx-auto mb-4">
                <CheckCircle size={32} />
              </div>
              <h3 className="text-xl font-semibold text-gray-800 mb-2">Best Price Guarantee</h3>
              <p className="text-gray-600">We offer the most competitive prices for all our tour packages without compromising quality.</p>
            </div>
            <div className="p-6 bg-blue-50 rounded-xl text-center hover:shadow-lg transition-shadow">
              <div className="w-16 h-16 bg-blue-100 text-blue-600 rounded-full flex items-center justify-center mx-auto mb-4">
                <Users size={32} />
              </div>
              <h3 className="text-xl font-semibold text-gray-800 mb-2">Expert Guides</h3>
              <p className="text-gray-600">Our professional tour guides ensure you have an immersive and safe travel experience.</p>
            </div>
            <div className="p-6 bg-blue-50 rounded-xl text-center hover:shadow-lg transition-shadow">
              <div className="w-16 h-16 bg-blue-100 text-blue-600 rounded-full flex items-center justify-center mx-auto mb-4">
                <Headphones size={32} />
              </div>
              <h3 className="text-xl font-semibold text-gray-800 mb-2">24/7 Support</h3>
              <p className="text-gray-600">Our customer support team is available round the clock to assist you during your trip.</p>
            </div>
          </div>
        </div>
      </section>

      {/* Testimonials */}
      <section className="py-16 bg-blue-900 text-white relative overflow-hidden">
         {/* Decorative Circle */}
        <div className="absolute -top-24 -right-24 w-96 h-96 bg-blue-800 rounded-full opacity-50 pointer-events-none"></div>

        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold mb-2">What Our Travelers Say</h2>
            <div className="h-1 w-20 bg-amber-400 mx-auto"></div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {TESTIMONIALS.map((testimonial) => (
              <div key={testimonial.id} className="bg-blue-800 p-8 rounded-xl border border-blue-700 relative">
                <div className="text-4xl text-amber-400 font-serif absolute top-4 left-4 opacity-30">"</div>
                <p className="text-blue-100 italic mb-6 relative z-10">{testimonial.comment}</p>
                <div className="flex items-center">
                  <img src={testimonial.image} alt={testimonial.name} className="w-12 h-12 rounded-full border-2 border-amber-400 mr-4" />
                  <div>
                    <h4 className="font-bold text-white">{testimonial.name}</h4>
                    <p className="text-xs text-blue-300 uppercase tracking-wider">{testimonial.role}</p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-16 bg-white">
        <div className="max-w-4xl mx-auto px-4 text-center">
          <h2 className="text-3xl font-bold text-blue-900 mb-4">Ready for your next adventure?</h2>
          <p className="text-gray-600 mb-8 text-lg">Let us handle the details while you enjoy the journey. Contact us today to plan your perfect trip.</p>
          <div className="flex flex-col sm:flex-row justify-center gap-4">
            <Link to="/contact" className="bg-amber-400 text-blue-900 hover:bg-amber-500 font-bold py-3 px-8 rounded-full transition-transform hover:-translate-y-1 shadow-lg">
              Contact Us
            </Link>
            <Link to="/packages" className="border-2 border-blue-900 text-blue-900 hover:bg-blue-50 font-bold py-3 px-8 rounded-full transition-colors">
              View Packages
            </Link>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Home;
