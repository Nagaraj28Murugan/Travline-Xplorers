
import { GoogleGenAI } from "@google/genai";

// Initialize the Gemini client
const ai = new GoogleGenAI({ apiKey: process.env.API_KEY || '' });

export const getChatResponse = async (message: string): Promise<string> => {
  try {
    if (!process.env.API_KEY) {
        return "I'm sorry, but I am currently offline (API Key missing). Please contact support.";
    }

    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: message,
      config: {
        systemInstruction: `You are "Travi", the AI Travel Assistant for TRAVLINE, a premium travel agency.
        
        Your role:
        1. Recommend destinations based on user preferences (budget, weather, type of trip).
        2. Briefly explain TRAVLINE's services (Flights, Hotels, Visas, Packages).
        3. Help users with itinerary ideas.
        4. Be friendly, professional, and concise.
        5. If a user wants to book, ask them to visit the Contact page or click "Book Now" on a package.
        
        Tone: Cheerful, adventurous, helpful.
        Keep responses under 100 words unless asked for a detailed itinerary.`,
      },
    });

    return response.text || "I'm having trouble connecting to the travel network right now. Please try again later.";
  } catch (error) {
    console.error("Gemini API Error:", error);
    return "I'm currently experiencing a brief layover (technical error). Please try again in a moment.";
  }
};

export const generateTransactionEmails = async (
  type: 'BOOKING' | 'CANCELLATION',
  details: {
    customerName: string;
    destination: string;
    date: string;
    travelers: number;
    amount: string;
    refId: string;
    paymentMethod?: string;
  }
): Promise<{ customerEmail: string; companyEmail: string } | null> => {
  try {
    if (!process.env.API_KEY) return null;

    let systemInstruction = '';
    
    if (type === 'BOOKING') {
      systemInstruction = `
        You are the Travel CRM Automation Bot for TRAVLINE.
        Trigger: "On Booking Created" & "On Payment Success".
        Action: Generate email templates.

        Context:
        - Customer: ${details.customerName}
        - Destination: ${details.destination}
        - Date: ${details.date}
        - Travelers: ${details.travelers}
        - Total Paid: ${details.amount}
        - Payment Method: ${details.paymentMethod}
        - Booking Ref: ${details.refId}
        
        Task:
        1. "customerEmail": A professional Booking Confirmation & Payment Receipt. Include a generated "Travel Tip" for ${details.destination}.
        2. "companyEmail": An Operations New Booking Alert containing all logistical details.
      `;
    } else {
      systemInstruction = `
        You are the Travel CRM Automation Bot for TRAVLINE.
        Trigger: "On Cancellation Requested".
        Action: Generate email templates.

        Context:
        - Customer: ${details.customerName}
        - Destination: ${details.destination}
        - Booking Ref: ${details.refId}
        - Refund Amount: ${details.amount}
        
        Task:
        1. "customerEmail": A Booking Cancellation Confirmation. Mention that the refund of ${details.amount} will be processed within 5-7 business days.
        2. "companyEmail": An Urgent Cancellation Alert for the operations team to cancel hotel/flight slots.
      `;
    }

    const prompt = `
      ${systemInstruction}
      
      Output strictly valid JSON format:
      {
        "customerEmail": "Subject: ... Body ...",
        "companyEmail": "Subject: ... Body ..."
      }
      Do not include markdown code blocks.
    `;

    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: prompt,
      config: {
        responseMimeType: 'application/json'
      }
    });

    const text = response.text;
    if (!text) return null;

    return JSON.parse(text);
  } catch (error) {
    console.error("Gemini Email Generation Error:", error);
    return null;
  }
};
