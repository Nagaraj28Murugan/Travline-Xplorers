
export interface Package {
  id: string;
  title: string;
  category: 'International' | 'Honeymoon' | 'Adventure' | 'Family' | 'Domestic';
  location: string;
  duration: string; // e.g. "5 Days / 4 Nights"
  price: number;
  image: string;
  gallery: string[];
  rating: number;
  description: string;
  itinerary: ItineraryDay[];
  inclusions: string[];
  exclusions: string[];
}

export interface ItineraryDay {
  day: number;
  title: string;
  description: string;
}

export interface Testimonial {
  id: string;
  name: string;
  role: string;
  comment: string;
  image: string;
}

export interface ServiceItem {
  id: string;
  title: string;
  description: string;
  icon: string;
  partners: string[];
}

export interface ChatMessage {
  role: 'user' | 'model';
  text: string;
}
