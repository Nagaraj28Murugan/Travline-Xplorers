import React, { createContext, useContext, useState, ReactNode } from 'react';

type CurrencyCode = 'USD' | 'INR' | 'EUR' | 'GBP' | 'AUD' | 'AED' | 'JPY' | 'CAD' | 'SGD';

interface CurrencyContextType {
  currency: CurrencyCode;
  setCurrency: (code: CurrencyCode) => void;
  formatPrice: (priceInUSD: number) => string;
  convertPrice: (priceInUSD: number) => number;
  exchangeRate: number;
}

const CurrencyContext = createContext<CurrencyContextType | undefined>(undefined);

const RATES: Record<CurrencyCode, number> = {
  USD: 1,
  INR: 84.5,
  EUR: 0.92,
  GBP: 0.78,
  AUD: 1.53,
  AED: 3.67,
  JPY: 151.5,
  CAD: 1.36,
  SGD: 1.35,
};

const LOCALE_MAP: Record<CurrencyCode, string> = {
    USD: 'en-US',
    INR: 'en-IN',
    EUR: 'de-DE',
    GBP: 'en-GB',
    AUD: 'en-AU',
    AED: 'en-AE',
    JPY: 'ja-JP',
    CAD: 'en-CA',
    SGD: 'en-SG'
};

export const CurrencyProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  // Default to INR as requested
  const [currency, setCurrency] = useState<CurrencyCode>('INR');

  const convertPrice = (priceInUSD: number) => {
    return priceInUSD * RATES[currency];
  };

  const formatPrice = (priceInUSD: number) => {
    const converted = convertPrice(priceInUSD);
    return new Intl.NumberFormat(LOCALE_MAP[currency], {
      style: 'currency',
      currency: currency,
      maximumFractionDigits: 0,
    }).format(converted);
  };

  return (
    <CurrencyContext.Provider value={{ 
        currency, 
        setCurrency, 
        formatPrice, 
        convertPrice,
        exchangeRate: RATES[currency] 
    }}>
      {children}
    </CurrencyContext.Provider>
  );
};

export const useCurrency = () => {
  const context = useContext(CurrencyContext);
  if (!context) {
    throw new Error('useCurrency must be used within a CurrencyProvider');
  }
  return context;
};