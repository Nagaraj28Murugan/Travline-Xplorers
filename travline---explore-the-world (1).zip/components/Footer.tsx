import React from 'react';
import { Link } from 'react-router-dom';
import { Facebook, Instagram, Twitter, Youtube, Mail, Phone, MapPin, Plane } from 'lucide-react';

const Footer: React.FC = () => {
  return (
    <footer className="bg-blue-900 text-white pt-12 pb-6">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {/* Company Info */}
          <div>
            <div className="flex items-center space-x-2 mb-4">
               <div className="bg-amber-400 p-1.5 rounded-full">
                <Plane className="h-5 w-5 text-blue-900" />
              </div>
              <span className="text-2xl font-bold text-white">TRAVLINE</span>
            </div>
            <p className="text-blue-200 text-sm mb-4 leading-relaxed">
              TRAVLINE helps you explore the world with premium packages, expert guidance, and unforgettable experiences. Your journey begins here.
            </p>
            <div className="flex space-x-4">
              <a href="#" className="bg-blue-800 hover:bg-amber-400 hover:text-blue-900 p-2 rounded-full transition-all"><Facebook size={18} /></a>
              <a href="#" className="bg-blue-800 hover:bg-amber-400 hover:text-blue-900 p-2 rounded-full transition-all"><Instagram size={18} /></a>
              <a href="#" className="bg-blue-800 hover:bg-amber-400 hover:text-blue-900 p-2 rounded-full transition-all"><Twitter size={18} /></a>
              <a href="#" className="bg-blue-800 hover:bg-amber-400 hover:text-blue-900 p-2 rounded-full transition-all"><Youtube size={18} /></a>
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h3 className="text-lg font-semibold text-amber-400 mb-4">Quick Links</h3>
            <ul className="space-y-2">
              <li><Link to="/" className="text-blue-200 hover:text-white hover:pl-2 transition-all">Home</Link></li>
              <li><Link to="/about" className="text-blue-200 hover:text-white hover:pl-2 transition-all">About Us</Link></li>
              <li><Link to="/packages" className="text-blue-200 hover:text-white hover:pl-2 transition-all">Tour Packages</Link></li>
              <li><Link to="/services" className="text-blue-200 hover:text-white hover:pl-2 transition-all">Our Services</Link></li>
              <li><Link to="/contact" className="text-blue-200 hover:text-white hover:pl-2 transition-all">Contact Us</Link></li>
            </ul>
          </div>

          {/* Packages */}
          <div>
            <h3 className="text-lg font-semibold text-amber-400 mb-4">Top Packages</h3>
            <ul className="space-y-2">
              <li><Link to="/packages" className="text-blue-200 hover:text-white hover:pl-2 transition-all">European Highlights</Link></li>
              <li><Link to="/packages" className="text-blue-200 hover:text-white hover:pl-2 transition-all">Bali Honeymoon</Link></li>
              <li><Link to="/packages" className="text-blue-200 hover:text-white hover:pl-2 transition-all">Dubai Luxury</Link></li>
              <li><Link to="/packages" className="text-blue-200 hover:text-white hover:pl-2 transition-all">Kerala Backwaters</Link></li>
              <li><Link to="/packages" className="text-blue-200 hover:text-white hover:pl-2 transition-all">Himalayan Trek</Link></li>
            </ul>
          </div>

          {/* Contact Info */}
          <div>
            <h3 className="text-lg font-semibold text-amber-400 mb-4">Contact Info</h3>
            <ul className="space-y-4">
              <li className="flex items-start space-x-3">
                <MapPin className="h-5 w-5 text-amber-400 mt-0.5 flex-shrink-0" />
                <span className="text-blue-200 text-sm">42 Bharathiyar street, Vengamedu, Karur 639006, Tamilnadu, India</span>
              </li>
              <li className="flex items-center space-x-3">
                <Phone className="h-5 w-5 text-amber-400 flex-shrink-0" />
                <span className="text-blue-200 text-sm">+91 86675 85449</span>
              </li>
              <li className="flex items-center space-x-3">
                <Mail className="h-5 w-5 text-amber-400 flex-shrink-0" />
                <span className="text-blue-200 text-sm">travline28@gmail.com</span>
              </li>
            </ul>
          </div>
        </div>

        <div className="border-t border-blue-800 mt-10 pt-6 text-center">
          <p className="text-blue-300 text-sm">
            &copy; {new Date().getFullYear()} TRAVLINE. All rights reserved.
          </p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;